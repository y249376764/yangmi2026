(function () {
  var TOPICS = ['新闻', '故事', '文化', '科技', '历史', '商业'];
  var DIRECTORY = 'https://itunes.apple.com/search';

  function http(value) {
    var url = String(value || '').trim();
    return /^https?:\/\/[^/\s?#]+[^\s]*$/i.test(url) ? url : '';
  }

  function text(host, value) {
    var raw = String(value || '').trim();
    var cdata = /^<!\[CDATA\[([\s\S]*)\]\]>$/.exec(raw);
    return (cdata ? cdata[1] : host.htmlDecode(raw)).trim();
  }

  function element(xml, tag) {
    var match = new RegExp('<' + tag + '(?=[\\s>])[^>]*>([\\s\\S]*?)<\\/' + tag + '\\s*>', 'i').exec(xml);
    return match ? match[1] : '';
  }

  function attribute(tag, name) {
    var match = new RegExp('\\s' + name + '\\s*=\\s*(["\'])([\\s\\S]*?)\\1', 'i').exec(tag);
    return match ? match[2] : '';
  }

  function read(host, feed, includeEpisodes) {
    var xml = host.getString(feed);
    // Protect CDATA from searches for XML tag boundaries.
    var sections = [];
    xml = xml.replace(/<!\[CDATA\[[\s\S]*?\]\]>/g, function (part) {
      return '\u0001' + (sections.push(part) - 1) + '\u0002';
    }).replace(/<!--[\s\S]*?-->/g, '');
    function field(block, name) {
      return text(host, element(block, name).replace(/\u0001(\d+)\u0002/g, function (_, index) {
        return sections[Number(index)];
      }));
    }
    var channel = element(xml, 'channel');
    if (!channel) throw new Error('这个链接没有返回播客 RSS 频道');
    var metadata = channel.replace(/<item(?:\s[^>]*)?>[\s\S]*?<\/item\s*>/gi, '');
    var art = /<itunes:image\s[^>]*>/i.exec(metadata);
    var detail = {
      title: field(metadata, 'title') || 'RSS 播客',
      author: field(metadata, 'itunes:author') || field(metadata, 'managingEditor'),
      intro: field(metadata, 'description').replace(/<[^>]*>/g, ' ').trim(),
      coverUrl: http(art && host.htmlDecode(attribute(art[0], 'href'))) ||
        http(field(element(metadata, 'image'), 'url'))
    };
    if (!includeEpisodes) return detail;
    var items = /<item(?:\s[^>]*)?>([\s\S]*?)<\/item\s*>/gi;
    var match, seen = Object.create(null);
    detail.episodes = [];
    while ((match = items.exec(channel))) {
      var enclosures = /<enclosure\s(?:[^>"']|"[^"]*"|'[^']*')*>/gi;
      var part;
      while ((part = enclosures.exec(match[1]))) {
        var type = attribute(part[0], 'type').toLowerCase();
        var url = http(host.htmlDecode(attribute(part[0], 'url')));
        if (!url || (!/^audio\//.test(type) &&
            !/\.(mp3|m4a|m4b|aac|ogg|opus|wav|flac|m3u8)(?:[?#]|$)/i.test(url))) continue;
        if (!seen[url]) {
          seen[url] = true;
          detail.episodes.push({ title: field(match[1], 'title') || '第 ' + (detail.episodes.length + 1) + ' 期', url: url });
        }
        break;
      }
    }
    if (!detail.episodes.length) throw new Error('RSS 中没有可播放的音频附件');
    return detail;
  }

  registerSource({
    id: '24d2503a8b32407fab5ca4a348666e15',
    name: 'apple博客',
    url: DIRECTORY,
    group: '播客',
    description: '搜索节目名，或粘贴公开播客 RSS 链接。每期节目作为一章。',
    categoryMenus: function () {
      return [{ title: '按主题浏览', tabs: TOPICS.map(function (topic) {
        return { title: topic, url: 'podcast:topic:' + topic };
      }) }];
    },
    categoryPage: function (url) {
      var prefix = 'podcast:topic:';
      var topic = String(url).slice(prefix.length);
      if (String(url).indexOf(prefix) !== 0 || TOPICS.indexOf(topic) < 0) {
        throw new Error('未知的播客分类');
      }
      var result = this.search(topic, 1);
      return { books: result.books, currentPage: 1, totalPage: 1 };
    },
    search: function (keywords, page) {
      var query = String(keywords || '').trim();
      if (page > 1 || !query) return { books: [], totalPage: 1 };
      var feed = http(query.replace(/^feed:\/\/(?=https?:\/\/)/i, '').replace(/^feed:\/\//i, 'https://'));
      if (feed) {
        var book = read(this.host, feed, false);
        book.bookUrl = feed;
        return { books: [book], totalPage: 1 };
      }
      var books = [], seen = Object.create(null);
      var host = this.host;
      function search(country) {
        var response = host.getJson(DIRECTORY + '?media=podcast&entity=podcast&limit=40&country=' +
          country + '&term=' + encodeURIComponent(query));
        (response.results || []).forEach(function (row) {
          var feedUrl = http(row.feedUrl), title = row.collectionName || row.trackName;
          if (!feedUrl || !title || seen[feedUrl]) return;
          seen[feedUrl] = true;
          books.push({ bookUrl: feedUrl, title: title, author: row.artistName || '',
            coverUrl: http(row.artworkUrl600) || http(row.artworkUrl100) || http(row.artworkUrl60) });
        });
      }
      search('cn');
      if (!books.length) search('us');
      return { books: books, totalPage: 1 };
    },
    bookDetail: function (url, loadEpisodes) {
      var feed = http(url);
      if (!feed) throw new Error('无效的 RSS 链接');
      return read(this.host, feed, loadEpisodes !== false);
    },
    audio: function (url) {
      var media = http(url);
      if (!media) throw new Error('无效的播客音频地址');
      return /\.m3u8(?:[?#]|$)/i.test(media) ? { url: media, headers: { 'X-Media-Type': 'hls' } } : media;
    }
  });
})();
