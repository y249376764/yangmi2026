// ============================================================
// 源 4：小懒听书 · 懒人听书
// 11 个大类平铺（每类 1000 本，20 本/页）+ 官方目录分页
// ============================================================
(function () {
  var CATS = [
    ['11', '玄幻奇幻'], ['8', '都市传说'], ['3109', '穿越架空'], ['14', '武侠仙侠'],
    ['3106', '青春校园'], ['12', '历史幻想'], ['3021', '科幻空间'], ['9042', '网游竞技'],
    ['9041', '热血军事'], ['44', '官场商战'], ['9287', '次元专区']
  ];
  var SIZE = 20;

  function idsKey(cid) { return 'xl_ids_' + cid; }

  function mapList(arr) {
    var books = [];
    for (var i = 0; i < (arr || []).length; i++) {
      var b = ssLrBook(arr[i], 'xl:b:');
      if (b) books.push(b);
    }
    return books;
  }

  function catPage(host, cid, page) {
    var ids = null, books = [], total = 0;
    var cached = host.readCache(idsKey(cid));
    if (cached) {
      try { ids = JSON.parse(cached); } catch (e) { ids = null; }
    }
    if (!ids || !ids.length) {
      var d = ssLrJson(host, 'https://m.lrts.me/ajax/getResourceList?dsize=' + SIZE +
        '&entityId=' + cid + '&entityType=1&pageNum=1&showFilters=0');
      ids = (d && d.bookIds) || [];
      if (ids.length) host.writeCache(idsKey(cid), JSON.stringify(ids));
      total = ids.length || (d && d.books ? d.books.length : 0);
      if (page <= 1) books = mapList(d && d.books);
    }
    if (page <= 1) {
      /* 首页已经取到，直接用 */
    } else {
      var slice = ids.slice((page - 1) * SIZE, page * SIZE);
      total = ids.length;
      if (slice.length) {
        var d2 = ssLrJson(host, 'https://m.lrts.me/ajax/getResourceList?dsize=' + SIZE +
          '&entityId=0&entityType=0&pageNum=0&showFilters=0&bookIds=' + encodeURIComponent(JSON.stringify(slice)));
        books = mapList(d2 && d2.books);
      }
    }
    var tp = Math.max(1, Math.ceil(total / SIZE));
    return { books: books, total: total, totalPage: tp };
  }

  registerSource({
    id: 'd2e9a45b6c7f4a1e9b3d0c85f62a7e41',
    name: '小懒听书 · 懒人听书',
    url: 'https://m.lrts.me/',
    group: '听书',
    description: '懒人听书：11 大类深翻（每类 1000 本）+ 官方目录分页 + 小白解析播放',
    multipleEpisodePages: true,

    categoryMenus: function () {
      var i, tabs = [];
      for (i = 0; i < CATS.length; i++) tabs.push({ title: CATS[i][1], url: 'xl:c:' + CATS[i][0] + ':1' });
      return [{ title: '分类', tabs: tabs }];
    },

    categoryPage: function (url) {
      var p = String(url || '').split(':');
      var cid = p[2] || '11', page = ssInt(p[3], 1) || 1;
      var r = catPage(this.host, cid, page);
      return {
        books: r.books,
        currentPage: page,
        totalPage: r.totalPage,
        nextUrl: page < r.totalPage ? ('xl:c:' + cid + ':' + (page + 1)) : null
      };
    },

    search: function (keywords, page) {
      var host = this.host;
      var d = ssEdge(host, '/lrts-search?name=' + encodeURIComponent(keywords) + '&page=' + (page || 1));
      var arr = (d && d.books) || [];
      var books = [];
      for (var i = 0; i < arr.length; i++) {
        var b = ssEdgeBook(arr[i], 'xl:b:');
        if (b) books.push(b);
      }
      return { books: books, currentPage: page || 1, totalPage: page || 1 };
    },

    bookDetail: function (bookUrl, loadEpisodes, loadFullPages) {
      var host = this.host, id = String(bookUrl || '').replace('xl:b:', '');
      var detail = { title: '', coverUrl: '', author: '', artist: '', intro: '', episodes: [] };
      if (!id) return detail;
      var info = ssLrJson(host, 'https://m.lrts.me/ajax/getBookInfo?id=' + id) || {};
      detail.title = ssName(info.name || info.title);
      detail.coverUrl = ssCover(info.bestCover || info.cover);
      detail.author = ssText(info.author);
      detail.artist = ssText(info.announcer);
      detail.intro = ssText(info.desc || info.description || info.intro);
      if (loadEpisodes) detail.episodes = ssLrMenu(host, id, !!loadFullPages);
      return detail;
    },

    audio: function (episodeUrl) {
      var raw = String(episodeUrl || '').replace('lr:ep:', '').replace('xl:e:', '');
      var a = raw.split('*');
      if (a.length < 2) throw new Error('章节地址无效');
      return ssLrAudio(this.host, a[0], a[1], a[2] || '');
    }
  });
})();
