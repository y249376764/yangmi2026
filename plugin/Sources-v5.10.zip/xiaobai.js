// ============================================================
// 源 3：小白·听书 · 懒人听书
// 推荐 15 组 + 3 个榜单 + 全站搜索 + 小白解析播放
// ============================================================
(function () {
  var SECTIONS = [
    '听友推荐', '都市传说', '玄幻奇幻', '历史幻想', '武侠仙侠',
    '悬疑爱情', '官场商战', '幻想言情', '科幻空间', '青春校园',
    '穿越架空', '网游竞技', '热血军事', '次元专区', '乡村生活'
  ];
  var RANKS = [['75', '热播榜'], ['738', '新书榜'], ['77', '热搜榜']];

  registerSource({
    id: 'b83f5c7d21e94a6fb0c4d8e19a72f560',
    name: '小白·听书 · 懒人听书',
    url: 'https://m.lrts.me/',
    group: '听书',
    description: '懒人听书：15 组推荐 + 3 个榜单 + 全站搜索（音频走小白解析）',

    categoryMenus: function () {
      var i, tabs = [], rankTabs = [];
      for (i = 0; i < SECTIONS.length; i++) tabs.push({ title: SECTIONS[i], url: 'xb:h:' + i });
      for (i = 0; i < RANKS.length; i++) rankTabs.push({ title: RANKS[i][1], url: 'xb:r:' + RANKS[i][0] });
      return [{ title: '推荐', tabs: tabs }, { title: '榜单', tabs: rankTabs }];
    },

    categoryPage: function (url) {
      var host = this.host, p = String(url || '').split(':');
      var books = [];
      if (p[1] === 'r') {
        var d = ssEdge(host, '/lrts-rank?rankId=' + p[2] + '&page=1');
        var list = (d && d.books) || [];
        for (var i = 0; i < list.length; i++) {
          var rb = ssEdgeBook(list[i], 'xb:b:');
          if (rb) books.push(rb);
        }
        return { books: books, currentPage: 1, totalPage: 1, nextUrl: null };
      }
      var idx = ssInt(p[2], 0);
      var home = ssEdge(host, '/lrts-home');
      var secs = (home && home.sections) || [];
      var sec = secs[idx] || secs[0] || null;
      var arr = (sec && sec.books) || [];
      for (var k = 0; k < arr.length; k++) {
        var b = ssEdgeBook(arr[k], 'xb:b:');
        if (b) books.push(b);
      }
      return { books: books, currentPage: 1, totalPage: 1, nextUrl: null };
    },

    search: function (keywords, page) {
      var host = this.host;
      var d = ssEdge(host, '/lrts-search?name=' + encodeURIComponent(keywords) + '&page=' + (page || 1));
      var arr = (d && d.books) || [];
      var books = [];
      for (var i = 0; i < arr.length; i++) {
        var b = ssEdgeBook(arr[i], 'xb:b:');
        if (b) books.push(b);
      }
      // 该接口只给一页（20 条），不再翻页
      return { books: books, currentPage: page || 1, totalPage: page || 1 };
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var id = String(bookUrl || '').replace('xb:b:', '');
      var detail = { title: '', coverUrl: '', author: '', artist: '', intro: '', episodes: [] };
      if (!id || !loadEpisodes) return detail;
      var d = ssEdge(this.host, '/lrts-book?bookId=' + encodeURIComponent(id));
      var chapters = (d && d.chapters) || [];
      var meta = (d && d.meta) || {};
      detail.title = ssName(meta.name);
      detail.coverUrl = ssCover(meta.cover);
      detail.author = ssText(meta.author);
      detail.intro = ssText(meta.description);
      var eps = [];
      for (var i = 0; i < chapters.length; i++) {
        var c = chapters[i];
        if (!c || !c.id) continue;
        eps.push({ title: ssText(c.title) || ('第 ' + (i + 1) + ' 集'), url: 'xb:e:' + String(c.id) });
      }
      detail.episodes = eps;
      return detail;
    },

    audio: function (episodeUrl) {
      var raw = String(episodeUrl || '').replace('xb:e:', '');
      var a = raw.split('*');
      if (a.length < 2) throw new Error('章节地址无效');
      return ssLrAudio(this.host, a[0], a[1], '');
    }
  });
})();
