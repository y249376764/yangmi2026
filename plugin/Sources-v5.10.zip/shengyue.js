// ============================================================
// 源 1：声阅APP · 酷我听书
// 分类 + 榜单 + 搜索 + 全量章节 + 播放
// ============================================================
(function () {
  var CATS = [
    ['44', '玄幻奇幻'], ['48', '武侠仙侠'], ['52', '穿越架空'], ['42', '都市传说'],
    ['57', '科幻竞技'], ['169', '幻想言情'], ['170', '独家定制'], ['207', '古代言情'],
    ['213', '影视原著'], ['45', '悬疑推理'], ['56', '历史军事'], ['41', '现代言情'],
    ['55', '青春校园'], ['61', '文学名著'], ['0|5', '相声评书'], ['0|1', '亲子儿童']
  ];
  var RANKS = [
    ['13', '27', '热播总榜'], ['1', '30', '有声小说榜'], ['15', '29', '畅销榜'],
    ['20', '128', 'VIP总榜'], ['11', '36', '儿童总榜'], ['19', '77', '相声曲艺榜'],
    ['2', '32', '历史总榜']
  ];

  function catUrl(cid, page) {
    var a = String(cid).split('|');
    var u = 'https://tingshu.kuwo.cn/v2/api/search/filter/albums?classifyId=' + a[0] +
      '&sortType=pubDate&rn=30&pn=' + page;
    if (a.length > 1) u += '&categoryId=' + a[1];
    return u;
  }

  function catBooks(host, cid, page) {
    var data = null;
    try {
      data = host.getJson(catUrl(cid, page), {
        headers: { 'User-Agent': SS_KW_UA, 'Referer': 'https://tingshu.kuwo.cn/', 'Accept-Encoding': 'identity' }
      });
    } catch (e) {
      data = null;
    }
    var body = (data && data.data) || {};
    var arr = body.data || [];
    var total = ssInt(body.total, arr.length);
    var books = [];
    for (var i = 0; i < arr.length; i++) {
      var b = ssKwBook(arr[i], 'sy:b:');
      if (b) books.push(b);
    }
    return { books: books, total: total };
  }

  registerSource({
    id: '9c4a71d2f3b84e0a9d6c5b21e7f80a3c',
    name: '声阅APP · 酷我听书',
    url: 'https://tingshu.kuwo.cn/',
    group: '听书',
    description: '酷我听书：16 个分类 + 7 个榜单 + 全站搜索',

    categoryMenus: function () {
      var i, tabs = [];
      for (i = 0; i < CATS.length; i++) tabs.push({ title: CATS[i][1], url: 'sy:c:' + CATS[i][0] + ':1' });
      var rtabs = [];
      for (i = 0; i < RANKS.length; i++) rtabs.push({ title: RANKS[i][2], url: 'sy:r:' + RANKS[i][0] + ':' + RANKS[i][1] + ':1' });
      return [{ title: '分类', tabs: tabs }, { title: '榜单', tabs: rtabs }];
    },

    categoryPage: function (url) {
      var host = this.host, p = String(url || '').split(':');
      if (p[1] === 'r') {
        var rpage = ssInt(p[4], 1) || 1;
        var d = ssEdge(host, '/kuwo-rank-data?tabId=' + p[2] + '&tagId=' + p[3] + '&pn=' + rpage);
        var list = (d && d.list) || [], books = [];
        for (var i = 0; i < list.length; i++) {
          var b = ssKwBook(list[i], 'sy:b:');
          if (b) books.push(b);
        }
        var rtp = 5;
        return {
          books: books,
          currentPage: rpage,
          totalPage: rtp,
          nextUrl: (books.length && rpage < rtp) ? ('sy:r:' + p[2] + ':' + p[3] + ':' + (rpage + 1)) : null
        };
      }
      var cid = p[2] || '44', page = ssInt(p[3], 1) || 1;
      var r = catBooks(host, cid, page);
      var tp = Math.max(1, Math.ceil(r.total / 30));
      return {
        books: r.books,
        currentPage: page,
        totalPage: tp,
        nextUrl: page < tp ? ('sy:c:' + cid + ':' + (page + 1)) : null
      };
    },

    search: function (keywords, page) {
      return ssKwSearch(this.host, keywords, page || 1, 'sy:b:');
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var id = String(bookUrl || '').replace('sy:b:', '');
      var detail = { title: '', coverUrl: '', author: '', artist: '', intro: '', episodes: [] };
      if (!id) return detail;
      if (!loadEpisodes) return detail;
      var d = ssKwDetail(this.host, id, 'sy:e:');
      detail.title = d.title || '';
      detail.coverUrl = d.coverUrl || '';
      detail.author = d.author || '';
      detail.artist = d.artist || '';
      detail.episodes = d.episodes || [];
      return detail;
    },

    audio: function (episodeUrl) {
      var rid = String(episodeUrl || '').replace('sy:e:', '');
      if (!rid) throw new Error('章节地址无效');
      return ssKwAudio(this.host, rid);
    }
  });
})();
