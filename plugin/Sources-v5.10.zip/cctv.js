// 央视直播（tv.cctv.com/live）：每个频道是一本“书”，只有一集“直播”（带 live 标记，宿主按直播来播放：不能拖动、不记进度）。
// 播的是央视网页播放器给出的纯音频 HLS 流（hls6），不下载视频，省流量。
// 版权原因有些时段不让播（接口里 play 为 0），这时把央视给的提示原样告诉用户。
(function () {
  var SITE = 'https://tv.cctv.com/live/';
  var LIVE_API = 'https://vdn.live.cntv.cn/api2/liveHtml5.do';
  var EPG_API = 'https://api.cntv.cn/epg/epginfo3';

  // 频道编号和名字：和直播页上的频道列表一致（编号既用于取直播流，也用于查节目单）
  var CHANNELS = [
    ['cctv1', 'CCTV-1 综合', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv1.png'], ['cctv2', 'CCTV-2 财经', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv2.png'], ['cctv3', 'CCTV-3 综艺', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv3.png'], ['cctv4', 'CCTV-4 中文国际（亚）', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv4.png'],
    ['cctveurope', 'CCTV-4 中文国际（欧）', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctveurope.png'], ['cctvamerica', 'CCTV-4 中文国际（美）', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctvamerica.png'],
    ['cctv5', 'CCTV-5 体育', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv5.png'], ['cctv5plus', 'CCTV-5+ 体育赛事', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv5plus.png'], ['cctv6', 'CCTV-6 电影', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv6.png'], ['cctv7', 'CCTV-7 国防军事', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv7.png'],
    ['cctv8', 'CCTV-8 电视剧', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv8.png'], ['cctvjilu', 'CCTV-9 纪录', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctvjilu.png'], ['cctv10', 'CCTV-10 科教', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv10.png'], ['cctv11', 'CCTV-11 戏曲', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv11.png'],
    ['cctv12', 'CCTV-12 社会与法', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv12.png'], ['cctv13', 'CCTV-13 新闻', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv13.png'], ['cctvchild', 'CCTV-14 少儿', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctvchild.png'], ['cctv15', 'CCTV-15 音乐', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv15.png'],
    ['cctv16', 'CCTV-16 奥林匹克', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv16.png'], ['cctv17', 'CCTV-17 农业农村', 'https://gitee.com/whykan/ssxz/raw/master/cctv-icons/cctv17.png']
  ];

  function channelOf(bookUrl) {
    var m = /^cctv-live:([a-z0-9]+)$/.exec(String(bookUrl));
    if (!m) throw new Error('不认识的央视频道地址');
    for (var i = 0; i < CHANNELS.length; i++) if (CHANNELS[i][0] === m[1]) return CHANNELS[i];
    throw new Error('没有这个央视频道：' + m[1]);
  }

  // 节目单按北京时间排，日期也要按北京时间算（手机可能在别的时区）
  function beijingDay(ms) {
    var d = new Date(ms + 8 * 3600 * 1000);
    function two(n) { return (n < 10 ? '0' : '') + n; }
    return d.getUTCFullYear() + two(d.getUTCMonth() + 1) + two(d.getUTCDate());
  }

  function beijingTime(sec) {
    var d = new Date(sec * 1000 + 8 * 3600 * 1000);
    function two(n) { return (n < 10 ? '0' : '') + n; }
    return two(d.getUTCHours()) + ':' + two(d.getUTCMinutes());
  }

  // 今天的节目单：频道编号 → { isLive: 正在播的节目, program: [{t, st, et}] }；取不到时返回空对象（不影响播放）
  function epg(host, codes) {
    try {
      return host.getJson(EPG_API + '?serviceId=shiyi&d=' + beijingDay(Date.now()) + '&c=' + codes.join(','), { headers: { Referer: SITE } }) || {};
    } catch (e) {
      host.log('节目单取不到：' + e.message);
      return {};
    }
  }

  function toBook(ch, guide) {
    var now = str(guide, 'isLive');
    return {
      bookUrl: 'cctv-live:' + ch[0], title: ch[1], coverUrl: ch[2], author: '央视',
      status: now ? '正在播：' + now : '直播',
      intro: now ? '正在播：' + now : ''
    };
  }

  function list(host, channels) {
    var guide = epg(host, channels.map(function (c) { return c[0]; }));
    return channels.map(function (c) { return toBook(c, guide[c[0]]); });
  }

  registerSource({
    id: '5b2e9c7a41d84f0e9a3c6d18e7f2b045', name: '央视直播', url: SITE, group: '广播',
    description: '央视各频道的电视直播，只播声音（纯音频流，省流量）。部分时段因版权不能播放，会显示央视的提示。',
    categoryMenus: function () {
      return [{ title: '央视', tabs: [{ title: '全部频道', url: 'cctv-channels' }] }];
    },
    categoryPage: function (url) {
      if (url !== 'cctv-channels') throw new Error('不认识的央视分类地址');
      return { books: list(this.host, CHANNELS), currentPage: 1, totalPage: 1 };
    },
    // 按频道名字或编号找，比如“新闻”“13”“CCTV-5”
    search: function (keywords, page) {
      if (page > 1) return { books: [], totalPage: 1 };
      var q = String(keywords).replace(/\s+/g, '').toLowerCase();
      if (!q) return { books: [], totalPage: 1 };
      var hits = CHANNELS.filter(function (c) {
        var name = c[1].replace(/\s+/g, '').toLowerCase();
        return name.indexOf(q) >= 0 || c[0].indexOf(q) >= 0 || name.indexOf('cctv-' + q) >= 0;
      });
      return { books: hits.length ? list(this.host, hits) : [], totalPage: 1 };
    },
    bookDetail: function (bookUrl) {
      var ch = channelOf(bookUrl), guide = epg(this.host, [ch[0]])[ch[0]];
      var now = Date.now() / 1000;
      // 简介里放今天的节目单，正在播的那一条前面标出来
      var lines = items(guide, 'program').map(function (p) {
        var on = int(p, 'st') <= now && now < int(p, 'et');
        return (on ? '▶ ' : '   ') + beijingTime(int(p, 'st')) + '  ' + str(p, 't');
      });
      var current = str(guide, 'isLive');
      return {
        title: ch[1], coverUrl: ch[2], author: '央视', status: current ? '正在播：' + current : '直播',
        intro: (current ? '正在播：' + current + '\n\n' : '') + (lines.length ? '今天的节目（北京时间）：\n' + lines.join('\n') : ''),
        episodes: [{ title: '直播', url: 'cctv-live:' + ch[0], live: true }]
      };
    },
    audio: function (url) {
      var ch = channelOf(url), host = this.host;
      var text = host.getString(LIVE_API + '?channel=pa://cctv_p2p_hd' + ch[0] + '&client=html5', { headers: { Referer: SITE } });
      // 返回的是一段脚本：var html5VideoData = '{...}';getHtml5VideoData(html5VideoData);
      var m = /html5VideoData\s*=\s*'([\s\S]*?)';/.exec(text);
      var data = parseJson(m ? m[1] : text);
      if (str(data, 'play') === '0') throw new Error(str(data, 'tip_msg') || '这个时段暂时不能播放');
      var stream = str(data, 'hls_url.hls6');
      if (!stream) throw new Error('央视没有给出这个频道的音频流');
      return { url: stream, headers: { 'X-Media-Type': 'hls', Referer: SITE } };
    }
  });
})();
