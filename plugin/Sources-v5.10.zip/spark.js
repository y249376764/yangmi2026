// ============================================================
// 星火听书源 · 公用工具（酷我听书 / 懒人听书）
// 仅 ES5 语法，供四端通用插件引擎（Rhino）使用
// ============================================================

var SS_API = 'https://backend.appmiaoda.com/projects/supabase364143248983240704/functions/v1';
var SS_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJhdXRoZW50aWNhdGVkIiwiZXhwIjoyMTA2MjQ1NzE2LCJpc3MiOiJzdXBhYmFzZSIsInJvbGUiOiJhbm9uIiwic3ViIjoiYW5vbiJ9.hIxrDQcZb3uM-yggkosEsRuBuPlzSAIFK2S_h_OcCyU';
var SS_UA = 'Mozilla/5.0 (Linux; Android 12; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';
var SS_KW_UA = 'Mozilla/5.0 (Linux; Android 12; M2101K9C) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.99 Mobile Safari/537.36';

// ---------- 文本 / 数字 ----------
function ssText(v) {
  var s = (v === null || v === undefined) ? '' : String(v);
  s = s.replace(/<[^>]*>/g, ' ');
  s = s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<')
       .replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  return s.replace(/\s+/g, ' ').replace(/^ | $/g, '').trim();
}

function ssInt(v, d) {
  var n = parseInt(String(v === null || v === undefined ? '' : v).replace(/[^\d-]/g, ''), 10);
  return isNaN(n) ? (d || 0) : n;
}

function ssCover(u) {
  var s = (u === null || u === undefined) ? '' : String(u);
  if (s.indexOf('//') === 0) return 'https:' + s;
  if (s.indexOf('http://') === 0) return 'https://' + s.substring(7);
  return s;
}

// 专辑名里常用 "|" 分隔长标题，取第一段更好看
function ssName(v) {
  return ssText(String(v === null || v === undefined ? '' : v).split('|')[0]);
}

// ---------- 秒数 -> 时长说明 ----------
function ssDur(sec) {
  var n = ssInt(sec, 0);
  if (!n) return '';
  var m = Math.floor(n / 60), s = n % 60;
  return m + ':' + (s < 10 ? '0' + s : s);
}

// ---------- 小白后端（edge functions）----------
function ssEdge(host, path) {
  var headers = { 'apikey': SS_KEY, 'Authorization': 'Bearer ' + SS_KEY };
  try {
    return host.getJson(SS_API + path, { headers: headers });
  } catch (e) {
    try { host.log('edge 失败：' + path + ' ' + e.message); } catch (e2) { }
    return null;
  }
}

// edge 接口返回的书 -> 插件书结构
function ssEdgeBook(b, scheme) {
  if (!b || b.id === null || b.id === undefined || b.id === '') return null;
  var ar = ssText(b.narrator && b.narrator !== '未知' ? b.narrator : b.author);
  return {
    bookUrl: scheme + String(b.id),
    title: ssName(b.title || b.name) || '未命名',
    coverUrl: ssCover(b.cover),
    author: ssText(b.author),
    artist: ar,
    intro: ssText(b.description || b.subtitle)
  };
}

// ---------- 酷我听书 ----------
// 统一的书卡映射（search.kuwo.cn / tingshu / edge 三种来源）
function ssKwBook(x, scheme) {
  if (!x) return null;
  var id = String(x.albumid || x.id || x.albumId || '');
  if (!id || id === 'undefined') return null;
  var ar = ssName(x.aartist || x.artist || x.artistName);
  var cnt = ssInt(x.musiccnt || x.songNum || x.songTotal || x.songnum);
  var desc = '';
  if (ar && ar !== '佚名') desc = '演播 ' + ar;
  if (cnt) desc += (desc ? ' · ' : '') + '共 ' + cnt + ' 集';
  return {
    bookUrl: scheme + id,
    title: ssName(x.name || x.albumName || x.title) || '未命名',
    coverUrl: ssCover(x.img || x.coverImg || x.cover),
    author: ssText(x.author),
    artist: (ar && ar !== '佚名') ? ar : '',
    intro: desc
  };
}

// 酷我装配式搜索（search.kuwo.cn，30 条/页，pn 从 0 开始）
function ssKwSearch(host, keywords, page, scheme) {
  var pn = Math.max(0, (page || 1) - 1);
  var url = 'http://search.kuwo.cn/r.s?client=kt&all=' + encodeURIComponent(keywords) +
    '&ft=album&newsearch=1&itemset=web_2013&pn=' + pn + '&rn=30&rformat=json&encoding=utf8&mobi=1';
  var data = null;
  try {
    data = host.getJson(url, { headers: { 'User-Agent': SS_KW_UA, 'Referer': 'https://tingshu.kuwo.cn/', 'Accept-Encoding': 'identity' } });
  } catch (e) {
    data = null;
  }
  var arr = (data && data.albumlist) || [];
  var total = ssInt(data && data.total, arr.length);
  if (!arr.length && pn === 0) {
    // 兜底走小白后端的酷我搜索（不分页）
    var d = ssEdge(host, '/kuwo-search?keyword=' + encodeURIComponent(keywords));
    arr = (d && d.books) || [];
    total = (d && d.total) || arr.length;
  }
  var books = [], seen = {};
  for (var i = 0; i < arr.length; i++) {
    var b = ssKwBook(arr[i], scheme);
    if (!b || seen[b.bookUrl]) continue;
    seen[b.bookUrl] = 1;
    books.push(b);
  }
  var totalPage = Math.max(1, Math.ceil(total / 30));
  return { books: books, currentPage: page || 1, totalPage: totalPage };
}

// 酷我章节音频地址
function ssKwAudio(host, rid) {
  var d = ssEdge(host, '/kuwo-play?rid=' + encodeURIComponent(rid));
  var u = d && (d.url || (d.data && (d.data.url || d.data.url2)));
  if (!u) {
    try {
      var m = host.getJson('http://mobi.kuwo.cn/mobi.s?f=web&user=0&source=kwplayercar_ar_6.0.0.9_B_jiakong_vh.apk&type=convert_url_with_sign&rid=' +
        encodeURIComponent(rid) + '&br=128kmp3', { headers: { 'User-Agent': SS_KW_UA, 'Referer': 'https://tingshu.kuwo.cn/' } });
      u = m && m.data && (m.data.url || m.data.url2);
    } catch (e) {
      u = '';
    }
  }
  u = u ? String(u) : '';
  if (u.indexOf('#') >= 0) u = u.split('#')[0];
  if (u.indexOf('http') !== 0) throw new Error('这一集暂时取不到音频，换一集或稍后再试');
  return { url: u, headers: { 'User-Agent': SS_KW_UA } };
}

// 酷我专辑详情 + 章节（小白后端，一次拿全量章节）
function ssKwDetail(host, albumId, scheme) {
  var d = ssEdge(host, '/kuwo-albuminfo?albumId=' + encodeURIComponent(albumId));
  var chapters = (d && d.chapters) || [];
  if (!chapters.length) {
    var d2 = ssEdge(host, '/kuwo-episodes?albumId=' + encodeURIComponent(albumId));
    chapters = (d2 && d2.chapters) || [];
  }
  var meta = (d && d.meta) || {};
  var eps = [];
  for (var i = 0; i < chapters.length; i++) {
    var c = chapters[i];
    if (!c || c.id === null || c.id === undefined) continue;
    eps.push({ title: ssText(c.title) || ('第 ' + (i + 1) + ' 集'), url: scheme + String(c.id) });
  }
  return {
    title: ssName(meta.name),
    coverUrl: ssCover(meta.cover),
    author: ssText(meta.author),
    artist: ssText(meta.artist),
    intro: '',
    episodes: eps
  };
}

// ---------- 懒人听书 ----------
var SS_LR_UA = 'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

function ssLrJson(host, url) {
  try {
    var r = host.getJson(url, { headers: { 'User-Agent': SS_LR_UA, 'Referer': 'https://m.lrts.me/', 'X-Requested-With': 'XMLHttpRequest' } });
    return r || null;
  } catch (e) {
    return null;
  }
}

// 懒人原始书 -> 插件书结构
function ssLrBook(x, scheme) {
  if (!x || !x.name) return null;
  var id = String(x.id || x.baseEntityId || '');
  if (!id) return null;
  var desc = [];
  if (x.author) desc.push('作者 ' + ssText(x.author).substring(0, 16));
  if (x.announcer) desc.push('主播 ' + ssText(x.announcer).substring(0, 20));
  if (x.sections) desc.push(ssInt(x.sections) + ' 集');
  else if (x.score) desc.push(x.score + ' 分');
  return {
    bookUrl: scheme + id,
    title: ssName(x.name) || '未命名',
    coverUrl: ssCover(x.cover || x.bestCover),
    author: ssText(x.author),
    artist: ssText(x.announcer),
    intro: desc.join(' · ')
  };
}

// 懒人音频：小白解析（tingshu8）优先
function ssLrAudio(host, bookId, section, sectionId) {
  var u = '';
  try {
    var j = host.getJson('http://www.tingshu8.top/yuan1/lrts.php?id=' + encodeURIComponent(String(bookId) + '*' + String(section)),
      { headers: { 'Referer': 'http://www.tingshu8.top/', 'User-Agent': SS_LR_UA } });
    if (j && j.code === 200 && j.data && j.data.url) u = String(j.data.url);
  } catch (e) { }
  if (!u) {
    // 兜底：懒人官方 getListenPath
    var url = 'https://m.lrts.me/ajax/getListenPath?entityId=' + bookId + '&entityType=3&opType=1&sections=[' + section + ']&type=0' +
      (sectionId ? ('&id=' + sectionId + '&section=' + section) : '');
    var d = ssLrJson(host, url);
    if (d && d.apiStatus === 0 && d.data && d.data.path) u = String(d.data.path);
  }
  if (u.indexOf('http') !== 0) throw new Error('这一集暂时取不到音频（可能属于付费/会员内容）');
  return { url: u, headers: {} };
}

// 懒人章节：用 m.lrts 官方目录（分页 50）
function ssLrMenu(host, bookId, loadFullPages) {
  var page = 1, pages = 1, eps = [], seen = {};
  do {
    var d = ssLrJson(host, 'https://m.lrts.me/ajax/getBookMenu?bookId=' + bookId + '&pageNum=' + page + '&pageSize=50&sortType=0');
    if (!d || !d.list || !d.list.length) break;
    pages = Math.max(1, Math.ceil(ssInt(d.sections, d.list.length) / 50));
    for (var i = 0; i < d.list.length; i++) {
      var c = d.list[i];
      if (!c) continue;
      var sec = ssInt(c.section, 0) || (eps.length + 1);
      var sid = String(c.id || c.sectionId || '');
      var eurl = 'lr:ep:' + bookId + '*' + sec + '*' + sid;
      if (seen[eurl]) continue;
      seen[eurl] = 1;
      eps.push({ title: ssText(c.name) || ('第 ' + sec + ' 集'), url: eurl });
    }
    if (!loadFullPages) break;
    host.progress(page + ' / ' + pages);
    page++;
    if (page > 200) break;
  } while (page <= pages);
  host.progress(null);
  return eps;
}
