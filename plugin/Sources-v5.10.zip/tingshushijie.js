// ============================================================
// 源 2：听书世界 · 酷我听书
// 分类（小白后端聚合）+ 热门关键词 + 搜索
// ============================================================
(function () {
  var CATS = [
    ['44', '', '玄幻奇幻'], ['48', '', '武侠仙侠'], ['52', '', '穿越架空'], ['42', '', '都市传说'],
    ['57', '', '科幻竞技'], ['169', '', '幻想言情'], ['170', '', '独家定制'], ['207', '', '古代言情'],
    ['213', '', '影视原著'], ['45', '', '悬疑推理'], ['56', '', '历史军事'], ['41', '', '现代言情'],
    ['55', '', '青春校园'], ['61', '', '文学名著'], ['0', '5', '相声评书'], ['0', '1', '亲子儿童']
  ];
  var HOT = ['有声小说', '评书', '单田芳', '郭德纲', '相声', '鬼吹灯', '盗墓笔记', '儿童故事', '广播剧', '百家讲坛'];

  function albumsUrl(cid, categoryId, page) {
    var u = '/kuwo-albums?classifyId=' + cid + '&pn=' + page;
    if (categoryId) u += '&categoryId=' + categoryId;
    return u;
  }

  registerSource({
    id: '4e7b2f90c1a34d5e8b6f0a27d3c95e18',
    name: '听书世界 · 酷我听书',
    url: 'https://tingshu.kuwo.cn/',
    group: '听书',
    description: '酷我听书：16 个分类 + 热门关键词直达 + 全站搜索',

    categoryMenus: function () {
      var i, tabs = [];
      for (i = 0; i < CATS.length; i++) tabs.push({ title: CATS[i][2], url: 'tsj:c:' + CATS[i][0] + ':' + CATS[i][1] + ':1' });
      var hots = [];
      for (i = 0; i < HOT.length; i++) hots.push({ title: HOT[i], url: 'tsj:k:' + HOT[i] });
      return [{ title: '分类', tabs: tabs }, { title: '热门', tabs: hots }];
    },

    categoryPage: function (url) {
      var host = this.host, p = String(url || '').split(':');
      if (p[1] === 'k') {
        // 热门关键词：直接借搜索接口，第一页作为分类页
        var kw = p.slice(2).join(':');
        var s = ssKwSearch(host, kw, 1, 'tsj:b:');
        return { books: s.books, currentPage: 1, totalPage: s.totalPage, nextUrl: null };
      }
      var cid = p[2] || '44', cat = p[3] || '', page = ssInt(p[4], 1) || 1;
      var d = ssEdge(host, albumsUrl(cid, cat, page));
      var arr = (d && d.books) || [];
      var total = (d && d.total) || arr.length;
      var books = [];
      for (var i = 0; i < arr.length; i++) {
        var b = ssEdgeBook(arr[i], 'tsj:b:');
        if (b) books.push(b);
      }
      var tp = Math.max(1, Math.ceil(total / 20));
      return {
        books: books,
        currentPage: page,
        totalPage: tp,
        nextUrl: page < tp ? ('tsj:c:' + cid + ':' + cat + ':' + (page + 1)) : null
      };
    },

    search: function (keywords, page) {
      return ssKwSearch(this.host, keywords, page || 1, 'tsj:b:');
    },

    bookDetail: function (bookUrl, loadEpisodes) {
      var id = String(bookUrl || '').replace('tsj:b:', '');
      var detail = { title: '', coverUrl: '', author: '', artist: '', intro: '', episodes: [] };
      if (!id || !loadEpisodes) return detail;
      var d = ssKwDetail(this.host, id, 'tsj:e:');
      detail.title = d.title;
      detail.coverUrl = d.coverUrl;
      detail.author = d.author;
      detail.artist = d.artist;
      detail.episodes = d.episodes;
      return detail;
    },

    audio: function (episodeUrl) {
      var rid = String(episodeUrl || '').replace('tsj:e:', '');
      if (!rid) throw new Error('章节地址无效');
      return ssKwAudio(this.host, rid);
    }
  });
})();
