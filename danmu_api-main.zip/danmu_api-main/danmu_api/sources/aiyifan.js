import BaseSource from './base.js';
import { log } from "../utils/log-util.js";
import { httpGet, updateQueryString } from "../utils/http-util.js";
import { convertToAsciiSum } from "../utils/codec-util.js";
import { hexToInt } from "../utils/danmu-util.js";
import { generateValidStartDate } from "../utils/time-util.js";
import { addAnime, removeEarliestAnime } from "../utils/cache-util.js";
import { titleMatches, getExplicitSeasonNumber, extractSeasonNumberFromAnimeTitle } from "../utils/common-util.js";
import { globals } from '../configs/globals.js';
import { AiyifanSigningProvider } from '../utils/aiyifan-util.js';

// =====================
// 获取爱壹帆弹幕
// =====================
export default class AiyifanSource extends BaseSource {
  constructor() {
    super();
    this.USER_AGENT = (
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
      "AppleWebKit/537.36 (KHTML, like Gecko) " +
      "Chrome/124.0.0 Safari/537.36"
    );

    // API 基础地址
    this.SEARCH_API      = "https://rankv21.tripdata.app/v3/list/briefsearch";
    this.PLAYLIST_API    = "https://m10.yfsp.tv/v3/video/languagesplaylist";
    this.VIDEO_API       = "https://m10.yfsp.tv/v3/video/play";
    this.DANMU_API       = "https://m10.yfsp.tv/api/video/getBarrage";
    this.DOMAIN_API      = "https://www.yfsp.tv/play";
    this.CONFIG_PAGE_API = "https://www.yfsp.tv/";
    this.signingProvider = new AiyifanSigningProvider({
      userAgent: this.USER_AGENT,
      configPageUrl: this.CONFIG_PAGE_API
    });
    this.inflightDanmuRequests = new Map();
  }

  extractEpisodeRequestKey(id) {
    try {
      return new URL(id).searchParams.get("id") ?? id;
    } catch {
      return id;
    }
  }

  /**
   * 搜索电视剧
   * @param {string} keyword - 搜索关键词
   * @param {number} page - 页码，默认为1
   * @param {number} size - 每页数量，默认为10
   * @returns {Promise<Object>} 搜索结果
   */
  async searchDrama(keyword, page = 1, size = 10) {
    const params = {
      tags: keyword,
      orderby: 4,
      page: page,
      size: size,
      desc: 1,
      isserial: -1
    };

    const headers = {
      "User-Agent": this.USER_AGENT,
      "Accept": "application/json"
    };

    log("info", `[aiyifan] [搜索] 关键词: ${keyword}, 页码: ${page}`);
    
    try {
      const urlWithParams = updateQueryString(this.SEARCH_API, params);
      const response = await httpGet(globals.makeProxyUrl(urlWithParams), { headers });
      
      const data = typeof response.data === "string" ? JSON.parse(response.data) : response.data;
      return data;
    } catch (error) {
      log("error", `[aiyifan] [搜索失败] 错误: ${error.message}`);
      return null;
    }
  }

  /**
   * 从搜索结果中提取剧目列表
   * @param {Object} searchResult - 搜索结果
   * @returns {Array} 剧目列表
   */
  extractDramaList(searchResult) {
    const dramas = [];
    const infoList = searchResult?.data?.info || [];

    if (!infoList.length) {
      log("warn", "[aiyifan] [警告] 搜索结果为空");
      return dramas;
    }

    for (const item of infoList) {
      const result = item.result || [];
      if (!result.length) {
        continue;
      }

      for (const dramaInfo of result) {
        const vid = dramaInfo.contxt;
        const title = dramaInfo.title;

        // 搜索结果里的 key 字段即为剧集 vid
        // 不同接口字段名可能不同，优先取 key
        dramas.push({
          contxt: vid,
          title: title,
          ...dramaInfo
        });
        log("info", `[aiyifan] [发现剧目] ${title}  vid=${vid}`);
      }
    }

    return dramas;
  }

  /**
   * 通过 languagesplaylist 接口获取该剧集的全部集信息
   * @param {string} vid - 剧集唯一标识
   * @returns {Promise<Array>} 集列表
   */
  async getPlaylist(vid) {
    const baseParams = {
      cinema: 1,
      vid: vid,
      lsk: 1,
      taxis: 0,
      cid: "0,1,4,152",
    };

    const headers = {
      "User-Agent": this.USER_AGENT,
      "Accept": "application/json"
    };

    log("info", `[aiyifan] [播放列表] 请求 vid: ${vid}`);
    
    try {
      const { data } = await this.signingProvider.signedGetJson(this.PLAYLIST_API, baseParams, headers, "播放列表");

      const episodes = [];
      const infoList = data.data?.info || [];
      for (const info of infoList) {
        for (const ep of info.playList || []) {
          episodes.push(ep);
        }
      }

      log("info", `[aiyifan] [播放列表] 共获取到 ${episodes.length} 集`);
      return episodes;
    } catch (error) {
      log("error", `[aiyifan] [播放列表失败] 错误: ${error.message}`);
      return [];
    }
  }

  /**
   * 获取视频播放信息，包括 uniqueKey
   * @param {string} epKey - 剧集的 key
   * @param {number} epId - 剧集的 id（可选，用于打印）
   * @returns {Promise<Object>} 包含 uniqueKey 等信息的 data 字典
   */
  async getVideoInfo(epKey, epId = null) {
    const baseParams = {
      cinema: 1,
      id: epKey,
      a: 0,
      lang: "none",
      usersign: 1,
      region: "GL.",
      device: 0,
      isMasterSupport: 1
    };

    const headers = {
      "User-Agent": this.USER_AGENT,
      "Accept": "application/json"
    };

    const epInfo = epId ? `(ID:${epId})` : "";
    log("info", `[aiyifan] [视频信息] 请求 key: ${epKey} ${epInfo}`);

    try {
      const { data, vv } = await this.signingProvider.signedGetJson(this.VIDEO_API, baseParams, headers, "视频信息");
      log("info", `[aiyifan] [视频信息] vv签名: ${vv.substring(0, 16)}...`);
      return data.data || {};
    } catch (error) {
      log("error", `[aiyifan] [视频信息失败] 错误: ${error.message}`);
      return null;
    }
  }

  /**
   * 从视频信息中提取 uniqueKey
   * @param {Object} videoInfo - 视频信息
   * @returns {string} uniqueKey
   */
  extractUniqueKey(videoInfo) {
    const info = videoInfo.info?.[0] || {};
    const uniqueKey = info.uniqueKey;
    if (uniqueKey) {
      log("info", `[aiyifan] [视频信息] 获取到 uniqueKey: ${uniqueKey}`);
    }
    return uniqueKey;
  }

  /**
   * 获取弹幕列表
   * @param {string} uniqueKey - 唯一标识
   * @param {number} page - 页码，默认为1
   * @param {number} size - 每页数量，默认为30000
   * @returns {Promise<Array>} 弹幕列表
   */
  async fetchBarrage(uniqueKey, page = 1, size = 30000) {
    const baseParams = {
      cinema: 1,
      page: page,
      size: size,
      uniqueKey: uniqueKey,
    };

    const headers = {
      "User-Agent": this.USER_AGENT,
    };

    log("info", `[aiyifan] [弹幕] 请求 uniqueKey: ${uniqueKey}`);

    try {
      const { data, vv } = await this.signingProvider.signedGetJson(this.DANMU_API, baseParams, headers, "弹幕");
      log("info", `[aiyifan] [弹幕] vv签名: ${vv.substring(0, 16)}...`);

      const danmuList = data.data?.info || [];
      log("info", `[aiyifan] [弹幕] 获取到 ${danmuList.length} 条弹幕`);
      return danmuList;
    } catch (error) {
      log("error", `[aiyifan] [弹幕失败] 错误: ${error.message}`);
      return [];
    }
  }

  /**
   * 搜索功能
   * @param {string} keyword - 搜索关键词
   * @returns {Promise<Array>} 搜索结果
   */
  async search(keyword) {
    log("info", `[aiyifan] 开始搜索: ${keyword}`);

    // Step 1: 搜索，拿到剧目列表
    const searchResult = await this.searchDrama(keyword);
    if (!searchResult) {
      log("error", "[aiyifan] 搜索失败，退出");
      return [];
    }

    const dramas = this.extractDramaList(searchResult);
    if (!dramas.length) {
      log("warn", "[aiyifan] 未找到剧目信息，退出");
      return [];
    }

    // 转换搜索结果格式
    const results = dramas.map(drama => {
      return {
        provider: "aiyifan",
        mediaId: drama.contxt,  // vid 作为 mediaId
        title: drama.title,
        type: drama.atypeName,  // 默认类型
        year: new Date(drama.postTime).getFullYear(),  // 年份信息可能需要从其他地方获取
        imageUrl: drama.imgPath || null,  // 图片链接
        episodeCount: 0 // 初始集数为0，后续获取
      };
    });

    log("info", `[aiyifan] 搜索完成，找到 ${results.length} 个结果`);
    return results;
  }

  /**
   * 获取剧集详情
   * @param {string} id - 剧集ID
   * @returns {Promise<Array>} 剧集列表
   */
  async getEpisodes(id) {
    log("info", `[aiyifan] 获取剧集详情: ${id}`);

    // 获取播放列表
    const episodes = await this.getPlaylist(id);
    if (!episodes.length) {
      log("error", "[aiyifan] 获取播放列表失败");
      return [];
    }

    // 转换为标准格式
    const result = episodes.map((ep, index) => ({
      vid: ep.key,  // 使用key作为vid
      id: ep.id,
      title: ep.name || `第${index + 1}集`,
      link: `${this.DOMAIN_API}/${id}?id=${ep.key}`
    }));

    log("info", `[aiyifan] 获取到 ${result.length} 个剧集`);
    return result;
  }

  /**
   * 处理搜索结果
   * @param {Array} sourceAnimes 原始数据
   * @param {string} queryTitle 关键词
   * @param {Array} curAnimes 结果池
   * @param {Map} detailStore 详情缓存
   * @param {number|null} querySeason 目标季度
   */
  async handleAnimes(sourceAnimes, queryTitle, curAnimes, detailStore = null, querySeason = null) {
    const tmpAnimes = [];

    if (!sourceAnimes || !Array.isArray(sourceAnimes)) {
      log("error", "[aiyifan] sourceAnimes is not a valid array");
      return [];
    }

    // 基础标题与季度匹配过滤
    let filteredAnimes = sourceAnimes.filter(anime => titleMatches(anime.title, queryTitle, querySeason));

    // 提取搜索词中的明确季度信息或使用传入的季度参数
    const resolvedQuerySeason = querySeason !== null ? querySeason : getExplicitSeasonNumber(queryTitle);

    // 初始列表预过滤机制：若用户指定了季度，优先检查结果中是否已包含匹配项
    if (resolvedQuerySeason !== null) {
      const seasonFiltered = filteredAnimes.filter(anime => {
        const s = extractSeasonNumberFromAnimeTitle(anime.title).season;
        return s === resolvedQuerySeason || (resolvedQuerySeason === 1 && s === null);
      });

      // 如果已命中目标，减少详情请求量
      if (seasonFiltered.length > 0) {
        filteredAnimes = seasonFiltered;
        log("info", `[aiyifan] 结果已命中目标季(第${resolvedQuerySeason}季)，跳过非目标季相关请求`);
      }
    }

    const processPromises = filteredAnimes.map(async (anime) => {
        try {
          // 获取剧集列表
          const eps = await this.getEpisodes(anime.mediaId);
          if (eps.length === 0) {
            log("info", `[aiyifan] ${anime.title} 无分集，跳过`);
            return;
          }

          // 构建链接
          const links = eps.map((ep, index) => ({
            name: ep.title || `${index + 1}`,
            url: ep.link,
            title: `【aiyifan】 ${ep.title}`
          }));

          if (links.length === 0) return;

          // 计算动漫ID
          const numericAnimeId = convertToAsciiSum(anime.mediaId);

          // 构建动漫对象
          const transformedAnime = {
            animeId: numericAnimeId,
            bangumiId: anime.mediaId,
            animeTitle: `${anime.title}(${anime.year || 'N/A'})【${anime.type}】from aiyifan`,
            type: anime.type,
            typeDescription: anime.type,
            imageUrl: anime.imageUrl,
            startDate: generateValidStartDate(anime.year),
            episodeCount: links.length,
            rating: 0,
            isFavorited: true,
            source: "aiyifan",
          };

          tmpAnimes.push(transformedAnime);
          addAnime({ ...transformedAnime, links }, detailStore);

          if (globals.animes.length > globals.MAX_ANIMES) {
            removeEarliestAnime();
          }
        } catch (error) {
          log("error", `[aiyifan] 处理 ${anime.title} 失败:`, error.message);
        }
      });

    await Promise.all(processPromises);

    this.sortAndPushAnimesByYear(tmpAnimes, curAnimes);
    return tmpAnimes;
  }

  /**
   * 获取某集的弹幕
   * @param {string} id - 视频ID
   * @returns {Promise<Array>} 弹幕列表
   */
  async getEpisodeDanmu(id) {
    log("info", `[aiyifan] 获取弹幕: ${id}`);

    const requestKey = this.extractEpisodeRequestKey(id);
    const inflightRequest = this.inflightDanmuRequests.get(requestKey);
    if (inflightRequest) {
      log("info", `[aiyifan] 复用进行中的弹幕请求: ${requestKey}`);
      return await inflightRequest;
    }

    const requestPromise = (async () => {
      // 从 URL 中提取 id 参数
      const videoId = requestKey;

      // 获取视频信息
      const videoInfo = await this.getVideoInfo(videoId);
      if (!videoInfo) {
        log("error", "[aiyifan] 获取视频信息失败");
        return [];
      }

      // 提取uniqueKey
      const uniqueKey = this.extractUniqueKey(videoInfo);
      if (!uniqueKey) {
        log("error", "[aiyifan] 未获取到uniqueKey");
        return [];
      }

      // 获取弹幕
      const danmuList = await this.fetchBarrage(uniqueKey);
      if (danmuList.length === 0) {
        log("info", "[aiyifan] 未获取到弹幕");
        return [];
      }

      // 按时间排序
      danmuList.sort((a, b) => (a.second || 0) - (b.second || 0));

      log("info", `[aiyifan] 获取到 ${danmuList.length} 条弹幕`);
      return danmuList;
    })();

    this.inflightDanmuRequests.set(requestKey, requestPromise);
    try {
      return await requestPromise;
    } finally {
      this.inflightDanmuRequests.delete(requestKey);
    }
  }

  /**
   * 获取某集的弹幕分片列表
   * @param {string} id - 视频ID
   * @returns {Promise<any>} 弹幕分片列表
   */
  async getEpisodeDanmuSegments(id) {
    // 这里可以实现分片逻辑，暂时返回基本结构
    const danmaku = await this.getEpisodeDanmu(id);
    
    // 创建分段列表
    const segmentList = [{
      "type": "aiyifan",
      "segment_start": 0,
      "segment_end": Math.max(...danmaku.map(d => d.second || 0), 0),
      "url": `${this.DANMU_API}?uniqueKey=${id}`
    }];

    return {
      "type": "aiyifan",
      "duration": Math.max(...danmaku.map(d => d.second || 0), 0),
      "segmentList": segmentList
    };
  }

  /**
   * 获取某集的分片弹幕
   * @param {any} segment - 分片信息
   * @returns {Promise<Array>} 分片弹幕
   */
  async getEpisodeSegmentDanmu(segment) {
    // 从segment中提取uniqueKey并获取弹幕
    const uniqueKey = segment.url?.split('uniqueKey=')[1];
    if (!uniqueKey) {
      return [];
    }
    
    return await this.getEpisodeDanmu(uniqueKey);
  }

  /**
   * 格式化弹幕
   * @param {Array} comments - 原始弹幕
   * @returns {Array} 格式化后的弹幕
   */
  formatComments(comments) {
    return comments.map(comment => {
      // 将弹幕转换为标准格式
      return {
        // 时间（秒）
        p: `${comment.second || 0},${comment.position === 1 ? 5 : 1},25,${hexToInt(comment.color.replace("#", ""))},0,0,0,0`, // 标准弹幕格式: time, type, fontsize, color, unix_timestamp, pool, uid, row_id
        m: comment.contxt || comment.content || '', // 弹幕内容
        like: comment.good, // 点赞数
        // 保留原始数据
        ...comment
      };
    });
  }
}
