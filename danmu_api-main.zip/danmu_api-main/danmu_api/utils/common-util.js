import { globals } from '../configs/globals.js';
import { log } from './log-util.js'
import { simplized, traditionalized } from './zh-util.js';

// =====================
// 通用工具方法
// =====================

// 打印数据前200个字符
export function printFirst200Chars(data) {
  let dataToPrint;

  if (typeof data === 'string') {
    dataToPrint = data;  // 如果是字符串，直接使用
  } else if (Array.isArray(data)) {
    dataToPrint = JSON.stringify(data);  // 如果是数组，转为字符串
  } else if (typeof data === 'object') {
    dataToPrint = JSON.stringify(data);  // 如果是对象，转为字符串
  } else {
    log("error", "[system] [common] Unsupported data type");
    return;
  }

  log("info", "[system] [common]", dataToPrint.slice(0, 200));  // 打印前200个字符
}

// 正则表达式：提取episode标题中的内容
export const extractEpisodeTitle = (title) => {
  const match = title.match(/【(.*?)】/);  // 匹配【】中的内容
  return match ? match[1] : null;  // 返回方括号中的内容，若没有匹配到，则返回null
};

// 正则表达式：提取anime标题中的内容
export const extractAnimeTitle = (str) => str.split('(')[0].trim();

// 提取年份的辅助函数
export function extractYear(animeTitle) {
  const match = animeTitle.match(/\((\d{4})\)/);
  return match ? parseInt(match[1]) : null;
}

export function convertChineseNumber(chineseNumber) {
  // 如果是阿拉伯数字，直接转换
  if (/^\d+$/.test(chineseNumber)) {
    return Number(chineseNumber);
  }

  // 中文数字映射（简体+繁体）
  const digits = {
    // 简体
    '零': 0, '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
    '六': 6, '七': 7, '八': 8, '九': 9,
    // 繁体
    '壹': 1, '貳': 2, '參': 3, '肆': 4, '伍': 5,
    '陸': 6, '柒': 7, '捌': 8, '玖': 9
  };

  // 单位映射（简体+繁体）
  const units = {
    // 简体
    '十': 10, '百': 100, '千': 1000,
    // 繁体
    '拾': 10, '佰': 100, '仟': 1000
  };

  let result = 0;
  let current = 0;
  let lastUnit = 1;

  for (let i = 0; i < chineseNumber.length; i++) {
    const char = chineseNumber[i];

    if (digits[char] !== undefined) {
      // 数字
      current = digits[char];
    } else if (units[char] !== undefined) {
      // 单位
      const unit = units[char];

      if (current === 0) current = 1;

      if (unit >= lastUnit) {
        // 更大的单位，重置结果
        result = current * unit;
      } else {
        // 更小的单位，累加到结果
        result += current * unit;
      }

      lastUnit = unit;
      current = 0;
    }
  }

  // 处理最后的个位数
  if (current > 0) {
    result += current;
  }

  return result;
}

// 解析fileName，提取动漫名称和平台偏好
export function parseFileName(fileName) {
  if (!fileName || typeof fileName !== 'string') {
    return { cleanFileName: '', preferredPlatform: '' };
  }

  const atIndex = fileName.indexOf('@');
  if (atIndex === -1) {
    // 没有@符号，直接返回原文件名
    return { cleanFileName: fileName.trim(), preferredPlatform: '' };
  }

  // 找到@符号，需要分离平台标识
  const beforeAt = fileName.substring(0, atIndex).trim();
  const afterAt = fileName.substring(atIndex + 1).trim();

  // 检查@符号后面是否有季集信息（如 S01E01）
  const seasonEpisodeMatch = afterAt.match(/^(\w+)\s+(S\d+E\d+)$/);
  if (seasonEpisodeMatch) {
    // 格式：动漫名称@平台 S01E01
    const platform = seasonEpisodeMatch[1];
    const seasonEpisode = seasonEpisodeMatch[2];
    return {
      cleanFileName: `${beforeAt} ${seasonEpisode}`,
      preferredPlatform: normalizePlatformName(platform)
    };
  } else {
    // 检查@符号前面是否有季集信息
    const beforeAtMatch = beforeAt.match(/^(.+?)\s+(S\d+E\d+)$/);
    if (beforeAtMatch) {
      // 格式：动漫名称 S01E01@平台
      const title = beforeAtMatch[1];
      const seasonEpisode = beforeAtMatch[2];
      return {
        cleanFileName: `${title} ${seasonEpisode}`,
        preferredPlatform: normalizePlatformName(afterAt)
      };
    } else {
      // 格式：动漫名称@平台（没有季集信息）
      return {
        cleanFileName: beforeAt,
        preferredPlatform: normalizePlatformName(afterAt)
      };
    }
  }
}

// 将用户输入的平台名称映射为标准平台名称
function normalizePlatformName(inputPlatform) {
  if (!inputPlatform || typeof inputPlatform !== 'string') {
    return '';
  }

  const input = inputPlatform.trim();

  // 直接返回输入的平台名称（如果有效）
  if (globals.allowedPlatforms.includes(input)) {
    return input;
  }

  // 如果输入的平台名称无效，返回空字符串
  return '';
}

// 根据指定平台创建动态平台顺序
export function createDynamicPlatformOrder(preferredPlatform) {
  if (!preferredPlatform) {
    return [...globals.platformOrderArr]; // 返回默认顺序的副本
  }

  // 验证平台是否有效
  if (!globals.allowedPlatforms.includes(preferredPlatform)) {
    log("warn", `[system] [common] Invalid platform: ${preferredPlatform}, using default order`);
    return [...globals.platformOrderArr];
  }

  // 创建新的平台顺序，将指定平台放在最前面
  const dynamicOrder = [preferredPlatform];

  // 添加其他平台（排除已指定的平台）
  for (const platform of globals.platformOrderArr) {
    if (platform !== preferredPlatform && platform !== null) {
      dynamicOrder.push(platform);
    }
  }

  // 最后添加 null（用于回退逻辑）
  dynamicOrder.push(null);

  return dynamicOrder;
}

/**
 * 净化搜索关键词（专门针对请求源阶段的温和版）
 * @param {string} str - 原始搜索词
 * @returns {string} 净化后的搜索词
 */
export function sanitizeSearchKeyword(str) {
  if (!str) return '';
  // 仅移除零宽字符、BOM等肉眼不可见的“幽灵字符”，保留空格和合法标点，确保源站搜索的命中率。
  return String(str).replace(/[\u200B-\u200F\uFEFF]/g, '').trim();
}

/**
 * 规范化结果标题（移除空格并清理修饰性符号）
 * @param {string} str - 输入字符串
 * @returns {string} 规范化后的字符串
 */
export function normalizeSpaces(str) {
  if (!str) return '';
  // 白名单模式：非白名单中的字符全部清理
  return String(str).replace(/[^\u4e00-\u9fa5\u3400-\u4DBF\u{20000}-\u{2EE5F}\u{30000}-\u{323AF}\u3040-\u30ff\uFF65-\uFF9F\uAC00-\uD7AFa-zA-Z0-9\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A\u2160-\u217F\u0400-\u04FF\u00C0-\u024F\u0370-\u03FF]/gu, '');
}

/**
 * 严格标题匹配函数
 * @param {string} title - 动漫标题
 * @param {string} query - 搜索关键词
 * @returns {boolean} 是否匹配
 */
export function strictTitleMatch(title, query) {
  if (!title || !query) return false;

  // 剧名杂音清理：移除画质/配音/版本等杂音词，避免阻塞匹配
  const tagFilter = globals.titleNoiseFilter || null;
  const cleanTitle = tagFilter ? title.replace(tagFilter, '').trim() : title;
  const cleanQuery = tagFilter ? query.replace(tagFilter, '').trim() : query;

  const t = normalizeSpaces(cleanTitle);
  const q = normalizeSpaces(cleanQuery);

  // 完全匹配
  if (t === q) return true;

  // 标题以搜索词开头，且后面为季号或有效关键词时，允许严格匹配通过
  if (t.startsWith(q) && t.length > q.length) {
    const suffix = t.substring(q.length);
    const seasonPattern = /^(?:[\dⅡⅢⅣⅤⅥⅦⅧⅨⅩ]|[sS]\d+|Season\s*\d+|Part\s*\d+|第\d+|[第]?\s*[零一二三四五六七八九十]+\s*[季期部]|年番|合集|部(?!分)|部分|篇|剧场|完结|最终)/;
    if (seasonPattern.test(suffix)) return true;
  }

  return false;
}

/**
 * 从文本中提取明确的季度数字
 * 支持提取包含阿拉伯数字或中文数字的季度标识
 * @param {string} text 需要解析的文本
 * @returns {number|null} 提取出的季度数字，未匹配到时返回 null
 */
export function getExplicitSeasonNumber(text) {
  if (!text) return null;
  const match = text.match(/(?:第\s*([0-9一二三四五六七八九十百千万]+)\s*[季期部])|(?:S(?:eason)?\s*(\d+))|(?:Part\s*(\d+))/i);
  if (match) {
    const numStr = match[1] || match[2] || match[3];
    if (numStr) {
      return convertChineseNumber(numStr); 
    }
  }
  return null;
}

/**
 * 标题匹配路由函数：支持严格模式，或 宽松模式下的"包含+相似度"混合策略
 * @param {string} title - 动漫标题
 * @param {string} query - 搜索关键词
 * @param {number|null} parsedSeason - 解析出的目标季度
 * @returns {boolean} 是否匹配
 */
export function titleMatches(title, query, parsedSeason = null, forceNonStrict = false, threshold = 0.8) {
  if (title == null || query == null) return false;

  const titleText = String(title);
  const queryText = String(query);
  if (!titleText || !queryText) return false;

  // 策略1：严格模式仅允许头部或完全匹配（forceNonStrict 为 true 时跳过，用于偏好记录等场景）
  if (!forceNonStrict && globals.strictTitleMatch) return strictTitleMatch(titleText, queryText);

  // 剧名杂音清理：移除画质/配音/版本等杂音词，避免阻塞匹配
  const tagFilter = globals.titleNoiseFilter || null;
  const cleanTitle = tagFilter ? titleText.replace(tagFilter, '').trim() : titleText;

  // 预处理：移除干扰字符并转小写，消除格式与大小写差异
  const t = normalizeSpaces(cleanTitle).toLowerCase();
  const q = normalizeSpaces(queryText).toLowerCase();

  // 预处理：构建搜索词变种池 (原词、简体、繁体)，利用 Set 去重
  let qList = [q];
  try {
    qList = [...new Set([queryText, simplized(queryText), traditionalized(queryText)])]
      .map(kw => normalizeSpaces(kw).toLowerCase()).filter(Boolean);
  } catch (e) {}

  // 季度特征提取：提前提取季数以支撑策略2的去季包含匹配
  const querySeason = parsedSeason !== null ? parsedSeason : getExplicitSeasonNumber(queryText);

  // 查询词含季号时，将去季后的干净查询词加入候选池
  // 避免如"间谍过家家 第一季"因"第一季"三字不存在于源标题而导致包含匹配失败
  if (querySeason !== null && parsedSeason === null) {
    const seasonStripped = queryText.replace(/(?:season|s|第)\s*[0-9一二三四五六七八九十]+\s*(?:季|期|部(?!分))?/gi, '').trim();
    if (seasonStripped && seasonStripped !== queryText) {
      qList = [...new Set([...qList, normalizeSpaces(seasonStripped).toLowerCase()])];
    }
  }

  // 查询词含杂音词时，将清理后的干净查询词加入候选池
  // 如"百花杀（真彩）"→ 追加"百花杀"，避免"真彩"二字导致包含匹配失败
  if (tagFilter) {
    const tagStripped = queryText.replace(tagFilter, '').trim();
    if (tagStripped && tagStripped !== queryText) {
      qList = [...new Set([...qList, normalizeSpaces(tagStripped).toLowerCase()])];
    }
  }

  // 季度特征校验：先于包含匹配执行，确保错误季度的标题不会因干净查询词误通过
  if (querySeason !== null) {
    const titleSeason = getExplicitSeasonNumber(titleText);

    if (querySeason > 1) {
      // 搜索指定续作(>1)时，仅当源标题明确包含季号时才校验季号一致性
      // 源标题无季号的不分季长剧不应被此规则拦截，交由上游源处理器决定
      if (titleSeason !== null && titleSeason !== querySeason) return false;
    } else if (querySeason === 1) {
      // 搜索第1季时，拦截明确标明为其他季度(如第2季、第3季)的结果
      if (titleSeason !== null && titleSeason !== 1) return false;
    }
  }

  // 策略2：包含匹配优先 (性能最优且准确，只要完整包含任意变种即匹配)
  if (qList.some(kw => t.includes(kw))) return true;

  // 策略3：相似度匹配 (阈值0.8)
  const simMatch = qList.some(kw => {
    // 长度差异过大，或纯英文/数字时，禁止使用相似度计算策略
    if (Math.abs(t.length - kw.length) > Math.max(t.length, kw.length) * 0.7 || /^[a-zA-Z0-9]+$/.test(kw)) {
      return false;
    }

    // 核心相似度计算：解决"和/与"等翻译差异
    let matchCount = 0;
    let tIndex = 0;

    for (const char of kw) {
      const foundIdx = t.indexOf(char, tIndex);
      if (foundIdx !== -1) {
        matchCount++;
        tIndex = foundIdx + 1;
      }
    }

    return (matchCount / kw.length) > threshold;
  });

  // 年份噪音兜底：前序策略均未命中时，尝试去年份后再次包含匹配
  // 如查询词含杂音年份"(2026)"但源标题不含，去年后可正常命中
  if (!simMatch) {
    const yearStripped = queryText.replace(/[\(\（]\s*(?:19|20)\d{2}\s*[\)\）]|\b(?:19|20)\d{2}\b/g, '').trim();
    if (yearStripped && yearStripped !== queryText) {
      // 去年份后可能残留杂音词，继续用配置的正则去除
      const cleanYear = tagFilter ? yearStripped.replace(tagFilter, '').trim() : yearStripped;
      const yearQ = normalizeSpaces(cleanYear).toLowerCase();
      // 仅当标题不含年份时才接受兜底，保留用户刻意用年份过滤的语义
      const titleHasYear = /[\(\（]\s*(?:19|20)\d{2}\s*[\)\）]|\b(?:19|20)\d{2}\b/.test(titleText);
      if (yearQ && t.includes(yearQ) && !titleHasYear) return true;
    }
  }

  return simMatch;
}

/**
 * 数据类型校验
 * @param {string} value - 值
 * @param {string} expectedType - 期望类型
 * @param {string} fieldName - 参数名称
 */
export function validateType(value, expectedType) {
  const fieldName = value?.constructor?.name;  // 获取字段名
  if (expectedType === "array") {
    if (!Array.isArray(value)) {
      throw new TypeError(`${value} 必须是一个数组，但传入的是 ${fieldName}`);
    }
  } else if (expectedType === "boolean") {
    // 对于 boolean 类型，允许任何可转换为布尔值的类型（number, boolean）
    if (typeof value !== "boolean" && typeof value !== "number") {
      throw new TypeError(`${value} 必须是 boolean 或 number，但传入的是 ${fieldName}`);
    }
  } else if (typeof value !== expectedType) {
    throw new TypeError(`${value} 必须是 ${expectedType}，但传入的是 ${fieldName}`);
  }
}

// 从 animeTitle 中提取季数和纯剧名
export function extractSeasonNumberFromAnimeTitle(animeTitle) {
  if (!animeTitle) return { season: null, baseTitle: null };
  // 先在原始标题上做拆分切除年份后缀，再去除非法字符
  const match = animeTitle.match(/^(.*?)\(\d{4}\)/);
  const rawTitleWithoutYear = match ? match[1].trim() : animeTitle.split("(")[0].trim();
  const titleWithoutYear = normalizeSpaces(rawTitleWithoutYear);

  // 1) 明确季数标识：第X季/期/部
  const explicitSeasonMatch = titleWithoutYear.match(/第\s*([0-9一二三四五六七八九十壹贰叁肆伍陆柒捌玖拾]+)\s*[季期部]/);
  if (explicitSeasonMatch) {
    return {
      season: convertChineseNumber(explicitSeasonMatch[1]),
      baseTitle: titleWithoutYear.replace(explicitSeasonMatch[0], "").trim(),
    };
  }

  // 2) S2/Season 2
  const seasonMatch = titleWithoutYear.match(/(?:S(?:eason)?|Season)\s*(\d+)/i);
  if (seasonMatch) {
    return {
      season: parseInt(seasonMatch[1], 10),
      baseTitle: titleWithoutYear.replace(seasonMatch[0], "").trim(),
    };
  }

  // 3) Part 2
  const partMatch = titleWithoutYear.match(/Part\s*(\d+)/i);
  if (partMatch) {
    return {
      season: parseInt(partMatch[1], 10),
      baseTitle: titleWithoutYear.replace(partMatch[0], "").trim(),
    };
  }

  // 4) 尾部阿拉伯数字（如"某某 2" 或 "某某2"，但不超过2位）
  const trailingNumber = titleWithoutYear.match(/(?:^|\s|[^\d])(\d{1,2})$/);
  if (trailingNumber) {
    const season = parseInt(trailingNumber[1], 10);
    // 尾部"00"等不合法的季号不视为季数标识（如"机动战士高达00"）
    if (season === 0) {
      return { season: null, baseTitle: titleWithoutYear };
    }
    return {
      season,
      baseTitle: titleWithoutYear.slice(0, titleWithoutYear.lastIndexOf(trailingNumber[1])).trim(),
    };
  }

  // 5) 尾部中文数字（如"某某二"）
  const trailingChinese = titleWithoutYear.match(/([一二三四五六七八九十壹贰叁肆伍陆柒捌玖拾]+)$/);
  if (trailingChinese) {
    return {
      season: convertChineseNumber(trailingChinese[1]),
      baseTitle: titleWithoutYear.replace(trailingChinese[0], "").trim(),
    };
  }

  return { season: null, baseTitle: titleWithoutYear };
}

// 从集标题中提取集数（支持多种格式：第1集、第01集、EP01、E01等）
export function extractEpisodeNumberFromTitle(episodeTitle) {
  if (!episodeTitle) return null;

  // 匹配格式：第1集、第01集、第1话、第1回等
  const chineseMatch = episodeTitle.match(/第(\d+)[集话回]/);
  if (chineseMatch) {
    return parseInt(chineseMatch[1], 10);
  }

  // 匹配格式：EP01、EP1、E01、E1等
  const epMatch = episodeTitle.match(/[Ee][Pp]?(\d+)/);
  if (epMatch) {
    return parseInt(epMatch[1], 10);
  }

  // 匹配格式：01、1（纯数字，通常在标题开头或结尾）
  const numberMatch = episodeTitle.match(/(?:^|\s)(\d+)(?:\s|$)/);
  if (numberMatch) {
    return parseInt(numberMatch[1], 10);
  }

  return null;
}

// 从标题中提取动漫名称、季数和集数
export function extractAnimeInfo(animeTitle, episodeTitle) {
  let {season, baseTitle} = extractSeasonNumberFromAnimeTitle(animeTitle);
  let episode = extractEpisodeNumberFromTitle(episodeTitle);

  return { baseTitle, season, episode };
}
