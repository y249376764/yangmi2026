// language=JavaScript
export const systemSettingsJsContent = /* javascript */ `
// 全局变量定义
let isMergeMode = false;
let stagingTags = [];

const UI_THEMES = {
    lavender: '经典默认',
    shinyo: '新叶绿',
    sakura: '哔哩粉',
    tianyi: '天依蓝',
    hatsune: '初音青',
    sakuragi: '樱木红',
    violet: '罗兰紫',
    amber: 'LCL橘',
};

const UI_THEME_STORAGE_KEY = 'logvar_ui_theme';
const UI_SCHEME_STORAGE_KEY = 'logvar_ui_color_scheme';

function getStoredTheme() {
    try {
        const theme = String(localStorage.getItem(UI_THEME_STORAGE_KEY) || '').toLowerCase();
        return Object.prototype.hasOwnProperty.call(UI_THEMES, theme) ? theme : null;
    } catch (error) {
        return null;
    }
}

function getStoredColorScheme() {
    try { return localStorage.getItem(UI_SCHEME_STORAGE_KEY) || null; } catch(e) { return null; }
}

function storeColorScheme(scheme) {
    try { localStorage.setItem(UI_SCHEME_STORAGE_KEY, scheme); } catch(e) {}
}

function storeTheme(theme) {
    try { localStorage.setItem(UI_THEME_STORAGE_KEY, theme); return true; } catch (error) { return false; }
}

function applyTheme(theme) {
    const normalizedTheme = String(theme || '').toLowerCase();
    const selectedTheme = Object.prototype.hasOwnProperty.call(UI_THEMES, normalizedTheme) ? normalizedTheme : 'lavender';
    document.body.dataset.theme = selectedTheme;

    document.querySelectorAll('[data-theme-option]').forEach(button => {
        const isSelected = button.dataset.themeOption === selectedTheme;
        button.setAttribute('aria-checked', String(isSelected));
    });

    const label = document.getElementById('theme-current-label');
    if (label) label.textContent = 'UI_THEME · ' + UI_THEMES[selectedTheme];
    if (typeof updateColorSchemeToggle === 'function') updateColorSchemeToggle();
    return selectedTheme;
}

function setThemeButtonsDisabled(disabled) {
    document.querySelectorAll('[data-theme-option]').forEach(button => {
        button.disabled = disabled;
    });
}

async function selectTheme(theme) {
    const selectedTheme = applyTheme(theme);
    const storedLocally = storeTheme(selectedTheme);
    setThemeButtonsDisabled(true);

    try {
        const result = await saveImportedConfigValue('UI_THEME', selectedTheme);
        if (!result || !result.success) {
            throw new Error(result?.message || '保存失败');
        }

        updateLocalImportedConfig('UI_THEME', selectedTheme);
        renderEnvList();
        addLog('界面主题已保存为: ' + UI_THEMES[selectedTheme], 'success');
    } catch (error) {
        const localMessage = storedLocally ? '，已保存在当前浏览器' : '，仅在当前页面生效';
        addLog('云端默认主题保存失败' + localMessage + ': ' + error.message, 'warn');
        customAlert('主题已应用' + localMessage + '。云端默认主题保存失败: ' + error.message);
    } finally {
        setThemeButtonsDisabled(false);
    }
}

applyTheme(getStoredTheme() || document.body.dataset.theme || 'lavender');

// 导出当前管理员可见的环境变量配置
async function exportSystemConfig() {
    try {
        const response = await fetch(buildApiUrl('/api/config', true));
        if (!response.ok) {
            throw new Error('获取配置失败: HTTP ' + response.status);
        }

        const config = await response.json();
        const values = config.originalEnvVars || {};
        const maskedKeys = Object.entries(values)
            .filter(([, value]) => typeof value === 'string' && /^\\*+$/.test(value))
            .map(([key]) => key);

        if (maskedKeys.length > 0) {
            customAlert('当前页面没有权限读取完整配置，无法导出脱敏配置。请使用 ADMIN_TOKEN 访问系统配置。');
            return;
        }

        const exportData = {
            format: 'danmu-api-config',
            version: 1,
            exportedAt: new Date().toISOString(),
            values
        };
        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        const date = new Date().toISOString().slice(0, 10);
        link.href = url;
        link.download = 'danmu-api-config-' + date + '.json';
        document.body.appendChild(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        addLog('配置文件导出成功，共 ' + Object.keys(values).length + ' 项', 'success');
    } catch (error) {
        addLog('配置文件导出失败: ' + error.message, 'error');
        customAlert('配置文件导出失败: ' + error.message);
    }
}

// 打开配置文件选择器
function triggerConfigImport() {
    const input = document.getElementById('config-import-file');
    if (!input) return;
    input.value = '';
    input.click();
}

function readConfigFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('读取配置文件失败'));
        reader.readAsText(file, 'utf-8');
    });
}

function normalizeImportedConfig(data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
        throw new Error('配置文件必须是 JSON 对象');
    }

    const values = data.values || data.variables || data.env || data;
    if (!values || typeof values !== 'object' || Array.isArray(values)) {
        throw new Error('配置文件中没有找到有效的 values 配置项');
    }

    const reservedKeys = new Set(['format', 'version', 'exportedAt']);
    const entries = [];
    const invalidKeys = [];
    const maskedKeys = [];

    Object.entries(values).forEach(([rawKey, rawValue]) => {
        const key = String(rawKey).trim();
        if (reservedKeys.has(key)) return;
        if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) {
            invalidKeys.push(key || '(空键名)');
            return;
        }

        if (rawValue !== null && typeof rawValue === 'object') {
            invalidKeys.push(key + ' (值必须是文本、数字或布尔值)');
            return;
        }

        let value = rawValue === null ? '' : String(rawValue);
        if (/^\\*+$/.test(value)) {
            maskedKeys.push(key);
            return;
        }
        if (key === 'UI_THEME') {
            value = value.trim().toLowerCase() || 'lavender';
            if (!Object.prototype.hasOwnProperty.call(UI_THEMES, value)) {
                invalidKeys.push(key + ' (不支持的主题: ' + value + ')');
                return;
            }
        }
        entries.push({ key, value });
    });

    if (invalidKeys.length > 0) {
        throw new Error('配置文件包含无效项目: ' + invalidKeys.slice(0, 8).join('、'));
    }
    if (entries.length === 0) {
        throw new Error(maskedKeys.length > 0 ? '配置文件中的值全部为脱敏值，无法导入' : '配置文件中没有可导入的配置');
    }

    // 令牌最后更新，避免导入过程中提前失去当前页面权限。
    const importPriority = {
        DEPLOY_PLATFROM_ACCOUNT: 10,
        DEPLOY_PLATFROM_PROJECT: 11,
        DEPLOY_PLATFROM_TOKEN: 12,
        TOKEN: 20,
        ADMIN_TOKEN: 30
    };
    entries.sort((a, b) => (importPriority[a.key] || 0) - (importPriority[b.key] || 0));

    return { entries, maskedKeys };
}

async function saveImportedConfigValue(key, value) {
    const request = (endpoint) => fetch(buildApiUrl(endpoint), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, value })
    }).then(response => response.json());

    let result = await request('/api/env/set');
    if (!result.success) {
        result = await request('/api/env/add');
    }
    return result;
}

function updateLocalImportedConfig(key, value) {
    for (const items of Object.values(envVariables)) {
        const item = items.find(entry => entry.key === key);
        if (item) {
            item.value = value;
            return;
        }
    }

    if (!envVariables.system) envVariables.system = [];
    const isTheme = key === 'UI_THEME';
    envVariables.system.push({
        key,
        value,
        type: isTheme ? 'select' : 'text',
        options: isTheme ? Object.keys(UI_THEMES) : [],
        description: isTheme ? '管理界面主题' : '从配置文件导入的配置项'
    });
}

// 读取并批量导入配置文件
async function importSystemConfigFile(file) {
    if (!file) return;

    try {
        const data = JSON.parse(await readConfigFile(file));
        const { entries, maskedKeys } = normalizeImportedConfig(data);
        const confirmed = await customConfirm(
            '即将覆盖 ' + entries.length + ' 项环境变量配置，导入过程可能需要一些时间。是否继续？',
            '确认导入配置'
        );
        if (!confirmed) return;

        showLoading('正在导入配置...', '准备导入 ' + entries.length + ' 项');
        const failed = [];

        for (let i = 0; i < entries.length; i++) {
            const { key, value } = entries[i];
            updateLoadingText('正在导入配置...', (i + 1) + '/' + entries.length + '  ' + key);
            try {
                const result = await saveImportedConfigValue(key, value);
                if (!result || !result.success) {
                    failed.push(key + ': ' + (result?.message || '保存失败'));
                } else {
                    updateLocalImportedConfig(key, value);
                    if (key === 'UI_THEME') {
                        applyTheme(value);
                        storeTheme(value);
                    }
                }
            } catch (error) {
                failed.push(key + ': ' + error.message);
            }
        }

        hideLoading();
        renderEnvList();
        renderPreview();

        if (failed.length > 0) {
            addLog('配置导入部分失败: ' + failed.join('；'), 'error');
            customAlert('配置导入完成，但有 ' + failed.length + ' 项失败：\\n' + failed.slice(0, 8).join('\\n'));
            return;
        }

        let successMessage;
        if (maskedKeys.length > 0) {
            addLog('配置导入完成，跳过 ' + maskedKeys.length + ' 项脱敏配置', 'warn');
            successMessage = '配置导入成功，已跳过 ' + maskedKeys.length + ' 项脱敏值配置。';
        } else {
            addLog('配置导入成功，共 ' + entries.length + ' 项', 'success');
            successMessage = '配置导入成功，共导入 ' + entries.length + ' 项配置。';
        }

        if (entries.some(entry => entry.key === 'TOKEN' || entry.key === 'ADMIN_TOKEN')) {
            successMessage += '\\n访问令牌已更新，请使用新 TOKEN 或 ADMIN_TOKEN 地址重新打开管理页面。';
        }
        customAlert(successMessage);
    } catch (error) {
        hideLoading();
        addLog('配置文件导入失败: ' + error.message, 'error');
        customAlert('配置文件导入失败: ' + error.message);
    }
}

// 显示清理缓存确认模态框
function showClearCacheModal() {
    selectAllCacheItems(true); // 每次打开恢复默认全选
    document.getElementById('clear-cache-modal').classList.add('active');
}

// 批量勾选或取消勾选所有缓存项，并同步已选数量
function selectAllCacheItems(checked) {
    document.querySelectorAll('#clear-cache-modal input[name="cacheItem"]').forEach(cb => {
        cb.checked = checked;
    });
    updateCacheClearCount();
}

// 刷新清理缓存弹窗中已勾选项的数量统计
function updateCacheClearCount() {
    const all = document.querySelectorAll('#clear-cache-modal input[name="cacheItem"]');
    const checked = document.querySelectorAll('#clear-cache-modal input[name="cacheItem"]:checked');
    const countEl = document.getElementById('cache-clear-count');
    if (countEl) {
        countEl.textContent = '已选 ' + checked.length + ' / ' + all.length;
    }
}

// 隐藏清理缓存确认模态框
function hideClearCacheModal() {
    document.getElementById('clear-cache-modal').classList.remove('active');
}

// 确认清理缓存
async function confirmClearCache() {
    // 收集勾选的缓存项
    const checkboxes = document.querySelectorAll('#clear-cache-modal input[name="cacheItem"]:checked');
    const items = Array.from(checkboxes).map(cb => cb.value);
    if (items.length === 0) {
        customAlert('请至少选择一项要清理的缓存');
        return;
    }

    // 检查部署平台配置
    const configCheck = await checkDeployPlatformConfig();
    if (!configCheck.success) {
        hideClearCacheModal();
        customAlert(configCheck.message);
        return;
    }

    hideClearCacheModal();
    showLoading('正在清理缓存...', '清除中，请稍候');
    addLog('开始清理缓存', 'info');

    try {
        // 调用真实的清理缓存API，附带勾选的待清理项
        const response = await fetch(buildApiUrl('/api/cache/clear', true), { // 使用admin token
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ items })
        });

        const result = await response.json();

        if (result.success) {
            updateLoadingText('清理完成', '缓存已成功清除');
            addLog('缓存清理完成', 'success');
            addLog('✅ 缓存清理成功！已清理: ' + JSON.stringify(result.clearedItems), 'success');
        } else {
            updateLoadingText('清理失败', '请查看日志了解详情');
            addLog('缓存清理失败: ' + result.message, 'error');
        }
    } catch (error) {
        updateLoadingText('清理失败', '网络错误或服务不可用');
        addLog('缓存清理请求失败: ' + error.message, 'error');
    } finally {
        setTimeout(() => {
            hideLoading();
        }, 10);
    }
}

// 显示重新部署确认模态框
function showDeploySystemModal() {
    document.getElementById('deploy-system-modal').classList.add('active');
}

// 隐藏重新部署确认模态框
function hideDeploySystemModal() {
    document.getElementById('deploy-system-modal').classList.remove('active');
}

// 确认重新部署系统
function confirmDeploySystem() {
    // 检查部署平台配置
    checkDeployPlatformConfig().then(configCheck => {
        if (!configCheck.success) {
            hideDeploySystemModal();
            customAlert(configCheck.message);
            return;
        }

        hideDeploySystemModal();
        showLoading('准备部署...', '正在检查系统状态');
        addLog('===== 开始系统部署 =====', 'info');

        // 获取当前部署平台
        fetch(buildApiUrl('/api/config', true))
            .then(response => response.json())
            .then(config => {
                const deployPlatform = config.envs.deployPlatform || 'node';
                addLog(\`检测到部署平台: \${deployPlatform}\`, 'info');

                if (deployPlatform.toLowerCase() === 'node') {
                    // Node部署不需要重新部署
                    setTimeout(() => {
                        hideLoading();
                        addLog('===== 部署完成 =====', 'success');
                        addLog('Node部署模式，环境变量已生效', 'info');
                        addLog('✅ Node部署模式 - 在Node部署模式下，环境变量修改后会自动生效，无需重新部署。系统已更新配置', 'success');
                    }, 150);
                } else {  
                    // 调用真实的部署API
                    fetch(buildApiUrl('/api/deploy', true), { // 使用admin token
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    })
                    .then(response => response.json())
                    .then(result => {
                        if (result.success) {
                            addLog('云端部署触发成功', 'success');
                            // 模拟云端部署过程
                            simulateDeployProcess();
                        } else {
                            hideLoading();
                            addLog(\`云端部署失败: \${result.message}\`, 'error');
                            addLog(\`❌ 云端部署失败: \${result.message}\`, 'error');
                        }
                    })
                    .catch(error => {
                        hideLoading();
                        addLog(\`云端部署请求失败: \${error.message}\`, 'error');
                        addLog(\`❌ 云端部署请求失败: \${error.message}\`, 'error');
                    });
                }
            })
            .catch(error => {
                hideLoading();
                addLog(\`获取部署平台信息失败: \${error.message}\`, 'error');
                console.error('获取部署平台信息失败:', error);
            });
    });
}

// 模拟云端部署过程
function simulateDeployProcess() {
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += Math.random() * 8;
        if (progress >= 100) {
            progress = 10;
            clearInterval(progressInterval);
        }
        updateProgress(progress);
    }, 300);

    // 模拟部署步骤
    const steps = [
        { delay: 100, text: '检查环境变量...', detail: '验证配置文件', log: '配置文件验证通过' },
        { delay: 5000, text: '触发云端部署...', detail: '部署到当前平台', log: '云端部署已触发' },
        { delay: 9500, text: '构建项目...', detail: '云端构建中', log: '云端构建完成' },
        { delay: 5000, text: '部署更新...', detail: '发布到生产环境', log: '更新已部署' },
        { delay: 5500, text: '服务重启...', detail: '应用新配置', log: '服务已重启' },
        { delay: 5000, text: '健康检查...', detail: '验证服务状态', log: '所有服务运行正常' },
    ];

    steps.forEach(step => {
        setTimeout(() => {
            updateLoadingText(step.text, step.detail);
            addLog(step.log, 'success');
        }, step.delay);
    });

    // 部署后检查服务是否可用
    setTimeout(() => {
        checkDeploymentStatus();
    }, 900); // 延长延迟以确保模拟部署过程完成
}

// 检查部署状态，每隔5秒请求/api/logs接口直到请求成功
function checkDeploymentStatus() {
    const checkInterval = setInterval(() => {
        updateLoadingText('部署完成，检查服务状态...', '正在请求 /api/logs 接口');
        addLog('正在检查服务状态...', 'info');

        fetch(buildApiUrl('/api/logs'))
            .then(response => {
                if (response.ok) {
                    // 请求成功，停止检查
                    clearInterval(checkInterval);
                    // 更新加载状态而不是立即隐藏
                    updateLoadingText('部署成功！', '服务已重启并正常运行');
                    addLog('===== 部署完成 =====', 'success');
                    addLog('部署版本: ' + latestVersion, 'info');
                    addLog('系统已更新并重启', 'success');
                    
                    // 部署完成后再次确认，访问/api/logs接口来确认部署完成
                    confirmDeploymentByLogs();
                } else {
                    addLog('服务检查中 - 状态码: ' + response.status, 'info');
                }
            })
            .catch(error => {
                addLog('服务检查中 - 连接失败: ' + error.message, 'info');
            });
    }, 500); // 每5秒检查一次
}

// 部署完成后通过访问/api/logs接口来确认部署完成
function confirmDeploymentByLogs() {
    // 部署完成后的确认检查
    let confirmationAttempts = 0;
    const maxAttempts = 3; // 最多尝试3次确认部署完成

    const confirmationInterval = setInterval(() => {
        confirmationAttempts++;
        updateLoadingText('部署完成确认中...', '正在确认部署完成 (' + confirmationAttempts + '/' + maxAttempts + ')');
        addLog('部署完成确认 - 尝试 ' + confirmationAttempts + '/' + maxAttempts, 'info');

        fetch(buildApiUrl('/api/logs'))
            .then(response => {
                if (response.ok) {
                    // 请求成功，停止确认检查
                    clearInterval(confirmationInterval);
                    // 显示成功信息后延迟隐藏加载遮罩
                    updateLoadingText('部署确认成功！', '服务已重启并正常运行');
                    addLog('部署确认成功 - /api/logs 接口访问正常', 'success');
                    
                    setTimeout(() => {
                        hideLoading();
                        // 显示成功弹窗
                        customAlert('🎉 部署成功！云端部署已完成，服务已重启，配置已生效');
                        addLog('🎉 部署成功！云端部署已完成，服务已重启，配置已生效', 'success');
                    }, 200);
                } else if (confirmationAttempts >= maxAttempts) {
                    // 达到最大尝试次数，停止确认检查
                    clearInterval(confirmationInterval);
                    updateLoadingText('部署确认完成', '服务已重启');
                    addLog('部署确认完成 - 已达到最大尝试次数', 'warn');
                    
                    setTimeout(() => {
                        hideLoading();
                        // 显示成功弹窗
                        customAlert('🎉 部署成功！云端部署已完成，服务已重启，配置已生效');
                        addLog('🎉 部署成功！云端部署已完成，服务已重启，配置已生效', 'success');
                    }, 200);
                } else {
                    addLog('部署确认中 - 状态码: ' + response.status, 'info');
                }
            })
            .catch(error => {
                if (confirmationAttempts >= maxAttempts) {
                    // 达到最大尝试次数，停止确认检查
                    clearInterval(confirmationInterval);
                    updateLoadingText('部署确认完成', '服务已重启');
                    addLog('部署确认完成 - 已达到最大尝试次数', 'warn');
                    
                    setTimeout(() => {
                        hideLoading();
                        // 显示成功弹窗
                        customAlert('🎉 部署成功！云端部署已完成，服务已重启，配置已生效');
                        addLog('🎉 部署成功！云端部署已完成，服务已重启，配置已生效', 'success');
                    }, 200);
                } else {
                    addLog('部署确认中 - 连接失败: ' + error.message, 'info');
                }
            });
    }, 5000); // 每5秒检查一次，用于确认部署完成
}

// 检查URL中的token是否与currentAdminToken匹配
function checkAdminToken() {
    let _reverseProxy = customBaseUrl; // 使用全局变量 customBaseUrl

    // 获取URL路径并提取token
    let urlPath = window.location.pathname;
    
    // 如果配置了反代路径，必须先剥离它
    if(_reverseProxy) {
        try {
            // 解析配置中的路径部分，例如 http://192.168.8.1:2333/danmu_api => /danmu_api
            let proxyPath = _reverseProxy.startsWith('http') 
                ? new URL(_reverseProxy).pathname 
                : _reverseProxy;
            
            // 确保移除尾部斜杠
            if (proxyPath.endsWith('/')) {
                proxyPath = proxyPath.slice(0, -1);
            }
            
            // 如果当前URL包含此前缀，则移除它
            if(proxyPath && urlPath.startsWith(proxyPath)) {
                urlPath = urlPath.substring(proxyPath.length);
            }
        } catch(e) {
            console.error("解析反代路径失败", e);
        }
    }

    const pathParts = urlPath.split('/').filter(part => part !== '');
    const urlToken = pathParts.length > 0 ? pathParts[0] : currentToken; // 如果没有路径段，使用默认token
    
    // 检查是否配置了ADMIN_TOKEN且URL中的token等于currentAdminToken
    return currentAdminToken && currentAdminToken.trim() !== '' && urlToken === currentAdminToken;
}

// 检查部署平台相关配置
async function checkDeployPlatformConfig() {
    // 首先检查是否配置了ADMIN_TOKEN
    if (!checkAdminToken()) {
        // 获取当前页面的协议、主机和端口
        const protocol = window.location.protocol;
        const host = window.location.host;
        
        let displayBase;
        if (customBaseUrl) {
            displayBase = customBaseUrl.startsWith('http') 
                ? customBaseUrl 
                : (protocol + '//' + host + customBaseUrl);
        } else {
            displayBase = protocol + '//' + host;
        }

        if (displayBase.endsWith('/')) {
            displayBase = displayBase.slice(0, -1);
        }
        
        return { success: false, message: '请先配置ADMIN_TOKEN环境变量并使用正确的token访问以启用系统部署功能！\\n\\n访问方式：' + displayBase + '/{ADMIN_TOKEN}' };
    }
    
    try {
        const response = await fetch(buildApiUrl('/api/config', true));
        if (!response.ok) {
            throw new Error('HTTP error! status: ' + response.status);
        }
        
        const config = await response.json();
        const deployPlatform = config.envs.deployPlatform || 'node';
        
        // 如果是node部署平台，只需要检查ADMIN_TOKEN
        if (deployPlatform.toLowerCase() === 'node') {
            return { success: true, message: 'Node部署平台，仅需配置ADMIN_TOKEN' };
        }
        
        // 对于其他部署平台，收集所有缺失的环境变量
        const missingVars = [];
        const deployPlatformProject = config.originalEnvVars.DEPLOY_PLATFROM_PROJECT;
        const deployPlatformToken = config.originalEnvVars.DEPLOY_PLATFROM_TOKEN;
        const deployPlatformAccount = config.originalEnvVars.DEPLOY_PLATFROM_ACCOUNT;
        
        if (!deployPlatformProject || deployPlatformProject.trim() === '') {
            missingVars.push('DEPLOY_PLATFROM_PROJECT');
        }
        
        if (!deployPlatformToken || deployPlatformToken.trim() === '') {
            missingVars.push('DEPLOY_PLATFROM_TOKEN');
        }
        
        // 对于需要账号ID的部署平台，还需要检查DEPLOY_PLATFROM_ACCOUNT
        if (['netlify', 'cloudflare', 'huggingface'].includes(deployPlatform.toLowerCase())) {
            if (!deployPlatformAccount || deployPlatformAccount.trim() === '') {
                missingVars.push('DEPLOY_PLATFROM_ACCOUNT');
            }
        }
        
        if (missingVars.length > 0) {
            const missingVarsStr = missingVars.join('、');
            return { success: false, message: '部署平台为' + deployPlatform + '，请配置以下缺失的环境变量：' + missingVarsStr };
        }
        
        return { success: true, message: deployPlatform + '部署平台配置完整' };
    } catch (error) {
        console.error('检查部署平台配置失败:', error);
        return { success: false, message: '检查部署平台配置失败: ' + error.message };
    }
}

// 获取并设置配置信息
async function fetchAndSetConfig() {
    const config = await fetch(buildApiUrl('/api/config', true)).then(response => response.json());
    const hasAdminToken = config.hasAdminToken;
    currentAdminToken = config.originalEnvVars?.ADMIN_TOKEN || '';
    return config;
}

// 检查并处理管理员令牌
function checkAndHandleAdminToken() {
    if (!checkAdminToken()) {
        // 禁用系统配置按钮并添加提示
        const envNavBtn = document.getElementById('env-nav-btn');
        if (envNavBtn) {
            envNavBtn.title = '请先配置ADMIN_TOKEN并使用正确的admin token访问以启用系统管理功能';
        }
    }
}

// 获取配置项类型的显示标签
function getEnvTypeLabel(type) {
    return type === 'boolean' ? '布尔' :
           type === 'number' ? '数字' :
           type === 'select' ? '单选' :
           type === 'map' ? '映射' :
           type === 'multi-select' ? '多选' : '文本';
}

// 渲染值输入控件
function renderValueInput(item) {
    const container = document.getElementById('value-input-container');
    const type = item ? item.type : editingType;
    const value = item ? item.value : '';
    const currentKey = item ? item.key : editingKeyName;

    if (type === 'boolean') {
        // 布尔开关
        // 对于LIKE_SWITCH变量，默认值设为true（开启状态）
        let checked;
        if (currentKey === 'LIKE_SWITCH' || currentKey === 'REMEMBER_LAST_SELECT') {
            // 如果值为空或未定义，LIKE_SWITCH和REMEMBER_LAST_SELECT默认为true（开启）
            checked = value === 'true' || value === true || (value === '' || value === undefined || value === null);
        } else {
            checked = value === 'true' || value === true;
        }
        container.innerHTML = \`
            <label>值</label>
            <div class="switch-container">
                <label class="switch">
                    <input type="checkbox" id="bool-value" \${checked ? 'checked' : ''}>
                    <span class="slider"></span>
                </label>
                <span class="switch-label" id="bool-label">\${checked ? '启用' : '禁用'}</span>
            </div>
        \`;

        document.getElementById('bool-value').addEventListener('change', function(e) {
            document.getElementById('bool-label').textContent = e.target.checked ? '启用' : '禁用';
        });

    } else if (type === 'number') {
        // 数字滚轮
        const min = item && item.min !== undefined ? item.min : 1;
        const max = item && item.max !== undefined ? item.max : 100;
        const currentValue = value || min;

        container.innerHTML = \`
            <label>值 (\${min}-\${max})</label>
            <div class="number-picker">
                <div class="number-controls">
                    <button type="button" class="number-btn" onclick="adjustNumber(1)">\${uiIcon('chevron-up')}</button>
                    <button type="button" class="number-btn" onclick="adjustNumber(-1)">\${uiIcon('chevron-down')}</button>
                </div>
                <div class="number-display" id="num-value">\${currentValue}</div>
            </div>
            <div class="number-range">
                <input type="range" id="num-slider" min="\${min}" max="\${max}" value="\${currentValue}"
                       oninput="updateNumberDisplay(this.value)">
            </div>
        \`;

    } else if (type === 'select') {
        // 标签选择
        const options = item && item.options ? item.options : ['option1', 'option2', 'option3'];
        const optionsInput = item ? '' : \`
            <div class="form-group margin-bottom-15">
                <label>可选项 (逗号分隔)</label>
                <input type="text" id="select-options" placeholder="例如: debug,info,warn,error"
                       value="\${options.join(',')}" onchange="updateTagOptions()">
            </div>
        \`; 

        container.innerHTML = \`
            \${optionsInput}
            <label>选择值</label>
            <div class="tag-selector" id="tag-selector">
                \${options.map(opt => \`
                    <div class="tag-option \${opt === value ? 'selected' : ''}"
                         data-value="\${opt}" onclick="selectTag(this)">
                        \${opt}
                    </div>
                \`).join('')}
            </div>
        \`;

    } else if (type === 'multi-select') {
        // 多选标签（可拖动排序）
        const options = item && item.options ? item.options : ['option1', 'option2', 'option3', 'option4'];
        // 确保value是字符串类型后再进行split操作
        const stringValue = typeof value === 'string' ? value : String(value || '');
        // 排序配置中重复项没有语义，渲染时顺便清理历史脏数据。
        const selectedValues = stringValue
            ? [...new Set(stringValue.split(',').map(v => v.trim()).filter(v => v))]
            : [];
        
        // 检查是否为 SOURCE_ORDER，如果是则不显示合并模式
        const shouldShowMergeMode = currentKey === 'MERGE_SOURCE_PAIRS' || currentKey === 'PLATFORM_ORDER';
        
        // 每次渲染时重置合并模式状态
        isMergeMode = false;
        stagingTags = [];

        const optionsInput = item ? '' : \`
            <div class="form-group margin-bottom-15">
                <label>可选项 (逗号分隔)</label>
                <input type="text" id="multi-options" placeholder="例如: auth,payment,analytics"
                       value="\${options.join(',')}" onchange="updateMultiOptions()">
            </div>
        \`; 

        container.innerHTML = \`
            \${optionsInput}
            <label>已选择 (拖动调整顺序)</label>
            <div class="multi-select-container">
                <div class="selected-tags \${selectedValues.length === 0 ? 'empty' : ''}" id="selected-tags">
                    \${selectedValues.map(val => \`
                        <div class="selected-tag" draggable="true" data-value="\${val}">
                            <span class="tag-text">\${val}</span>
                            <button type="button" class="remove-btn" onclick="removeSelectedTag(this)">×</button>
                        </div>
                    \`).join('')}
                </div>

                \${shouldShowMergeMode ? \`
                <div class="merge-mode-controls">
                    <div class="merge-mode-btn" id="merge-mode-toggle" onclick="toggleMergeMode()">
                        \${uiIcon('link')} 开启合并模式
                    </div>
                    <div class="form-help" style="margin: 0; margin-left: 10px;">
                        开启后点击下方选项将添加到暂存区,组合后点击 √ 确认
                    </div>
                </div>

                <div class="staging-area" id="staging-area">
                    <button type="button" class="confirm-merge-btn" onclick="confirmMergeGroup()" title="确认添加该组">\${uiIcon('check')}</button>
                </div>
                \` : ''}

                <label>可选项 (点击添加)</label>
                <div class="available-tags" id="available-tags">
                    \${options.map(opt => {
                        return \`
                            <div class="available-tag"
                                 data-value="\${opt}" onclick="addSelectedTag(this)">
                                \${opt}
                            </div>
                        \`;
                    }).join('')}
                </div>
            </div>

            \${currentKey === 'MERGE_SOURCE_PAIRS' ? \`
            <div style="margin-top: 8px; display: flex; justify-content: flex-end;">
                \${renderRecentDataButton()}
            </div>
            \${renderRecentDataPanel()}
            \` : ''}
        \`;

        // 设置拖动事件
        // 立即执行一次状态检查，确保已选项变灰
        setTimeout(updateTagStates, 0);
        setupDragAndDrop();

    } else if (type === 'map') {
        // 映射表类型
        const pairs = value ? value.split(';').map(pair => pair.trim()).filter(pair => pair) : [];
        const mapItems = pairs.map(pair => {
            if (pair.includes('->')) {
                const [left, right] = pair.split('->').map(s => s.trim());
                return { left, right };
            }
            return { left: pair, right: '' };
        });

        container.innerHTML = \`
            <label>映射配置</label>
            <textarea id="map-bulk-value" rows="6" placeholder="原值->映射值;原值2->映射值2">\${escapeHtml(value || '')}</textarea>
            <button type="button" class="btn btn-secondary" onclick="parseBulkMapItems()">\${uiIcon('refresh-cw')} 解析并更新列表</button>
            <div class="map-container" id="map-container">
                \${mapItems.map((item, index) => \`
                    <div class="map-item" data-index="\${index}">
                        <input type="text" class="map-input-left" placeholder="原始值" value="\${item.left}">
                        <span class="map-separator">-></span>
                        <input type="text" class="map-input-right" placeholder="映射值" value="\${item.right}">
                        <button type="button" class="btn btn-danger map-remove-btn" onclick="removeMapItem(this)">删除</button>
                    </div>
                \`).join('')}
                <div class="map-item-template" style="display: none;">
                    <input type="text" class="map-input-left" placeholder="原始值">
                    <span class="map-separator">-></span>
                    <input type="text" class="map-input-right" placeholder="映射值">
                    <button type="button" class="btn btn-danger map-remove-btn" onclick="removeMapItem(this)">删除</button>
                </div>
            </div>
            <div style="margin-top: 8px; display: flex; align-items: center; justify-content: space-between; gap: 8px;">
                <button type="button" class="btn btn-primary" onclick="addMapItem()">\${uiIcon('plus')} 添加映射项</button>
                \${renderRecentDataButton('btn btn-primary')}
            </div>
            \${renderRecentDataPanel()}
        \`;

        bindMapInputSync();

    } else {
        // 文本输入
        const currentKey = editingKeyName;
        const isBilibiliCookie = currentKey === 'BILIBILI_COOKIE';
        const isAiApiKey = currentKey === 'AI_API_KEY';
        const isColorPool = currentKey === 'COLOR_POOL';
        const isDanmuOffset = currentKey === 'DANMU_OFFSET';
		const isCustomMergeRules = currentKey === 'CUSTOM_MERGE_RULES';
        const offsetSources = item && item.sources ? item.sources : [];
        const isTitleFilter = currentKey === 'ANIME_TITLE_FILTER' || currentKey === 'EPISODE_TITLE_FILTER' || currentKey === 'TITLE_NOISE_FILTER';
        const recentDataBlock = isTitleFilter ? \`<div style="margin-top: 8px; display: flex; justify-content: flex-end;">\${renderRecentDataButton()}</div>\${renderRecentDataPanel()}\` : '';

        if (isColorPool) {
            // 自定义颜色池专用编辑界面
            const colors = parseColorPool(value);

            container.innerHTML = \`
                <label>颜色池配置 (CONVERT_COLOR 为 color 时生效)</label>
                <div id="color-pool-display" class="color-pool-display">
                    \${renderColorItems(colors)}
                </div>
                <div class="color-pool-picker">
                    <div class="color-pool-picker-inner">
                        <div id="color-wheel" class="color-wheel">
                            <div class="color-wheel-center"></div>
                            <div id="wheel-dot" class="color-wheel-dot" style="top: 2px; left: 53px; background: hsl(0,100%,50%);"></div>
                        </div>
                        <div class="color-pool-preview">
                            <div id="color-preview-swatch" class="color-pool-preview-swatch" style="background: #ff0000;"></div>
                            <span id="color-preview-hex" class="color-pool-preview-hex">#ff0000</span>
                        </div>
                        <div class="color-pool-lightness">
                            <span>亮度</span>
                            <input type="range" id="color-lightness" min="10" max="100" value="50">
                        </div>
                        <div class="color-pool-actions">
                            <button type="button" class="btn btn-primary btn-sm" onclick="addColorToPool()">添加到颜色池</button>
                            <button type="button" class="btn btn-primary btn-sm" onclick="addRandomColorToPool()">随机添加</button>
                        </div>
                    </div>
                </div>
                <div class="color-pool-actions">
                    <button type="button" class="btn btn-primary btn-sm" onclick="showBatchColorDialog()">批量添加</button>
                    <div class="spacer"></div>
                    <button type="button" class="btn btn-primary btn-sm" onclick="resetColorPool()">恢复默认</button>
                </div>
                <textarea id="text-value" style="display: none;">\${value}</textarea>
            \`;
            setTimeout(initColorWheel, 0);
        } else if (isDanmuOffset) {
            // DANMU_OFFSET 专用编辑界面
            const rows = value && value.length > 50 ? Math.min(Math.max(Math.ceil(value.length / 50), 3), 10) : 3;
            container.innerHTML = \`
                <label>变量值</label>
                <textarea id="text-value" placeholder="格式：剧名:秒 或 剧名/S01:秒 或 剧名@来源:秒 或 剧名/S01/E01@来源%:秒" rows="\${rows}" class="text-monospace">\${value}</textarea>
                <div style="margin-top: 8px; display: flex; align-items: center; justify-content: space-between; gap: 8px;">
                    <button type="button" class="btn btn-primary btn-sm" id="offset-rule-toggle" onclick="toggleOffsetRulePanel()">
                        \${uiIcon('plus')} 添加规则
                    </button>
                    \${renderRecentDataButton()}
                </div>
                \${renderRecentDataPanel('点击下方按钮可快捷填入规则表单：')}
                <div id="offset-rule-panel" class="offset-rule-panel">
                    <div class="form-help" style="margin: 0 0 8px 0;">季和集不填则对所有季/集生效</div>
                    <div class="offset-form-row">
                        <div style="flex: 2; min-width: 100px;">
                            <label class="offset-label">剧名 *</label>
                            <input type="text" id="offset-anime" class="offset-input" placeholder="例如: overlord">
                        </div>
                        <div style="width: 65px;">
                            <label class="offset-label">季</label>
                            <input type="number" id="offset-season" class="offset-input" placeholder="" min="1" max="99">
                        </div>
                        <div style="width: 65px;">
                            <label class="offset-label">集</label>
                            <input type="number" id="offset-episode" class="offset-input" placeholder="" min="1" max="999">
                        </div>
                        <div style="width: 85px;">
                            <label class="offset-label">偏移秒 *</label>
                            <input type="number" id="offset-seconds" class="offset-input" placeholder="90">
                        </div>
                    </div>
                    <div style="margin-bottom: 10px; display: flex; align-items: center; width: 100%;">
                        <label class="offset-label" style="display: flex; align-items: center; gap: 8px; cursor: pointer; margin: 0;">
                            启用百分比模式（按视频时长缩放全部弹幕时间）
                            <input type="checkbox" id="offset-use-percent" class="app-checkbox">
                        </label>
                    </div>
                    \${offsetSources.length > 0 ? \`
                    <div style="margin-bottom: 10px;">
                        <label class="offset-label">来源 (可选，不选则对所有来源生效)</label>
                        <div id="offset-sources" class="offset-sources">
                            \${offsetSources.map(src => \`
                                <div class="offset-source-tag" data-value="\${src}" onclick="toggleOffsetSource(this)">
                                    \${src}
                                </div>
                            \`).join('')}
                        </div>
                    </div>
                    \` : ''}
                    <div class="offset-actions">
                        <button type="button" class="btn btn-sm" onclick="toggleOffsetRulePanel()">取消</button>
                        <button type="button" class="btn btn-primary btn-sm" onclick="appendOffsetRule()">确认添加</button>
                    </div>
                </div>
            \`;
        } else if (isAiApiKey) {
            // AI API Key 专用编辑界面
            container.innerHTML = \`
                <div class="ai-apikey-editor">
                    <label>API Key 值</label>
                    <textarea class="form-group" id="text-value" placeholder="请输入 AI API Key" rows="3">\${value}</textarea>
                    <div class="form-help">支持 OpenAI 兼容的 API，需配合 AI_BASE_URL 和 AI_MODEL 配置使用</div>

                    <div class="ai-apikey-status" id="ai-apikey-status">
                        <span class="ai-status-icon">\${uiIcon('search')}</span>
                        <span class="ai-status-text">点击下方按钮测试连通性</span>
                    </div>
                    <div class="ai-apikey-actions" style="margin-bottom: 15px;">
                        <button type="button" class="btn btn-primary btn-sm" id="ai-verify-btn" onclick="verifyAiConnection()">
                            \${uiIcon('flask')} 测试连通性
                        </button>
                    </div>
                </div>
            \`;
        } else if (isBilibiliCookie) {
            // Bilibili Cookie 专用编辑界面
            const rows = value && value.length > 50 ? Math.min(Math.max(Math.ceil(value.length / 50), 3), 8) : 3;
            container.innerHTML = \`
                <div class="bili-cookie-editor">
                    <div class="bili-cookie-status" id="bili-cookie-status">
                        <span class="bili-status-icon">\${uiIcon('search')}</span>
                        <span class="bili-status-text">检测中...</span>
                    </div>
                    
                    <div class="bili-cookie-actions">
                        <button type="button" class="btn btn-primary btn-sm" onclick="startBilibiliQRLogin()">
                            \${uiIcon('qr-code')} 扫码登录
                        </button>
                    </div>
                    
                    <label>Cookie 值</label>
                    <textarea class="form-group" id="text-value" placeholder="SESSDATA=xxx; bili_jct=xxx; DedeUserID=xxx;" rows="\${rows}">\${value}</textarea>
                    <div class="form-help">推荐使用扫码登录自动获取，或手动粘贴包含 SESSDATA 和 bili_jct 的完整 Cookie</div>
                </div>
            \`;
            
            // 自动检测 Cookie 状态 + 监听输入变化（防抖）
            setTimeout(() => {
                autoCheckBilibiliCookieStatus();

                const inputEl = document.getElementById('text-value');
                if (inputEl) {
                    let debounceTimer = null;
                    inputEl.addEventListener('input', () => {
                        if (debounceTimer) clearTimeout(debounceTimer);
                        debounceTimer = setTimeout(() => {
                            autoCheckBilibiliCookieStatus();
                        }, 600);
                    });
                }
            }, 120);
        } else if (isCustomMergeRules) {
            // CUSTOM_MERGE_RULES 专用编辑界面
            const rows = value && value.length > 50 ? Math.min(Math.max(Math.ceil(value.length / 50), 3), 10) : 3;
            container.innerHTML = \`
                <label>变量值</label>
                <textarea id="text-value" placeholder="格式：副源 -> 主源 | 路由规则 或 副源 × 主源" rows="\${rows}" class="text-monospace">\${value || ''}</textarea>
                <div style="margin-top: 8px; display: flex; align-items: center; justify-content: space-between; gap: 8px;">
                    <button type="button" class="btn btn-primary btn-sm" id="merge-rule-toggle" onclick="toggleMergeRulePanel()">
                        \${uiIcon('plus')} 添加规则
                    </button>
                    \${renderRecentDataButton()}
                </div>
                \${renderRecentDataPanel('点击下方按钮可快捷填入规则表单：')}
                <div id="merge-rule-panel" class="offset-rule-panel">
                    <div class="offset-form-row">
                        <div style="flex: 1; min-width: 120px;">
                            <label class="offset-label">副源实体（副源剧名@源）</label>
                            <input type="text" id="merge-sec-entity" class="offset-input" placeholder="例: 我推的孩子/S01@bahamut" onfocus="setMergeFocus('sec')">
                        </div>
                        <div style="width: 80px; display: flex; flex-direction: column; align-items: center; justify-content: flex-end;">
                            <label class="offset-label" style="text-align: center; display: block;">关系：<span id="merge-action-hint" style="font-weight: normal; color: var(--theme-muted);">合并</span></label>
                            <select id="merge-action" class="offset-input" onchange="onMergeActionChange()" style="cursor: pointer; text-align: center; font-weight: bold; font-size: 15px;">
                                <option value="->">-&gt;</option>
                                <option value="×">×</option>
                            </select>
                        </div>
                        <div style="flex: 1; min-width: 120px;">
                            <label class="offset-label">主源实体（主源剧名@源）</label>
                            <input type="text" id="merge-prim-entity" class="offset-input" placeholder="例: 我推的孩子/S03@dandan" onfocus="setMergeFocus('prim')">
                        </div>
                    </div>
                    <div class="offset-form-row" id="merge-route-row">
                        <div style="flex: 1;">
                            <label class="offset-label">集数路由规则 (选填，可多组。例如: E01>E01,E25~E35>E25~E35)</label>
                            <input type="text" id="merge-route-rule" class="offset-input" placeholder="留空则交由系统自动计算偏移">
                        </div>
                    </div>
                    <div style="margin-bottom: 10px;">
                        <label class="offset-label">快速追加来源至当前聚焦的输入框 (没有 @ 则追加 @xxx，已存在 @ 则追加 &xxx 合并写法)</label>
                        <div class="offset-sources">
                            \${offsetSources.map(src => \`
                                <div class="offset-source-tag" onclick="appendSourceToMerge('\${src}')">\${src}</div>
                            \`).join('')}
                        </div>
                    </div>
                    <div class="offset-actions">
                        <button type="button" class="btn btn-sm" onclick="toggleMergeRulePanel()">取消</button>
                        <button type="button" class="btn btn-primary btn-sm" onclick="appendMergeRule()">确认添加</button>
                    </div>
                </div>
            \`;
        } else if (value && value.length > 50) {
            const rows = Math.min(Math.max(Math.ceil(value.length / 50), 3), 10);
            container.innerHTML = \`
                <label>变量值 *</label>
                <textarea id="text-value" placeholder="例如: localhost" rows="\${rows}" class="text-monospace">\${value}</textarea>
                \${recentDataBlock}
            \`;
        } else {
            container.innerHTML = \`
                <label>变量值 *</label>
                <input type="text" id="text-value" placeholder="例如: localhost" value="\${value}" required>
                \${recentDataBlock}
            \`; 
        }
    }
}

// ===== 颜色池操作函数 =====

// 色轮状态
let wheelHue = 0;
let wheelLightness = 50;
let wheelCleanup = null;

// 解析颜色池字符串为十进制数组
function parseColorPool(str) {
    if (!str) return [];
    return str.split(',').map(c => parseInt(c.trim(), 10)).filter(c => !isNaN(c) && c >= 0 && c <= 16777215);
}

// 渲染颜色池色块 HTML
function renderColorItems(colors) {
    if (colors.length === 0) return '<span class="color-pool-empty">未配置，将使用默认颜色池</span>';
    return colors.map((c, i) => \`
        <div class="color-pool-item">
            <span class="color-pool-swatch" style="background: #\${c.toString(16).padStart(6, '0')};"></span>
            <span class="color-pool-value">\${c}</span>
            <button type="button" class="color-pool-remove" onclick="removeColorFromPool(\${i})">&times;</button>
        </div>
    \`).join('');
}

// HSL -> RGB -> 十进制
function hslToDecimal(h, s, l) {
    s /= 100;
    l /= 100;
    const k = n => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, 9 - k(n), 1));
    const r = Math.round(f(0) * 255);
    const g = Math.round(f(8) * 255);
    const b = Math.round(f(4) * 255);
    return (r << 16) | (g << 8) | b;
}

// 更新色轮预览
function updateWheelPreview() {
    const dec = hslToDecimal(wheelHue, 100, wheelLightness);
    const hex = '#' + dec.toString(16).padStart(6, '0');
    const swatch = document.getElementById('color-preview-swatch');
    const hexLabel = document.getElementById('color-preview-hex');
    const dot = document.getElementById('wheel-dot');
    if (swatch) swatch.style.background = hex;
    if (hexLabel) hexLabel.textContent = hex;
    if (dot) dot.style.background = hex;
}

// 初始化色轮交互
function initColorWheel() {
    if (wheelCleanup) wheelCleanup();

    const wheel = document.getElementById('color-wheel');
    const slider = document.getElementById('color-lightness');
    if (!wheel) return;

    let dragging = false;

    function handleWheelEvent(e) {
        const rect = wheel.getBoundingClientRect();
        const cx = rect.width / 2;
        const cy = rect.height / 2;
        const x = e.clientX - rect.left - cx;
        const y = e.clientY - rect.top - cy;
        const dist = Math.sqrt(x * x + y * y);
        const outerR = rect.width / 2;
        const innerR = outerR * 0.22;
        if (dist < innerR || dist > outerR) return;
        let angle = Math.atan2(y, x) * 180 / Math.PI + 90;
        if (angle < 0) angle += 360;
        wheelHue = Math.round(angle % 360);
        const dot = document.getElementById('wheel-dot');
        if (dot) {
            const r = (innerR + outerR) / 2;
            const rad = (wheelHue - 90) * Math.PI / 180;
            dot.style.left = (cx + r * Math.cos(rad) - 7) + 'px';
            dot.style.top = (cy + r * Math.sin(rad) - 7) + 'px';
        }
        updateWheelPreview();
    }

    const onMove = e => {
        if (dragging) handleWheelEvent(e);
    };
    const onTouchMove = e => {
        if (dragging) handleWheelEvent(e.touches[0]);
    };
    const onUp = () => {
        dragging = false;
    };

    wheel.addEventListener('mousedown', e => {
        dragging = true;
        handleWheelEvent(e);
    });
    wheel.addEventListener('touchstart', e => {
        dragging = true;
        handleWheelEvent(e.touches[0]);
        e.preventDefault();
    }, { passive: false });
    document.addEventListener('mousemove', onMove);
    document.addEventListener('touchmove', onTouchMove, { passive: false });
    document.addEventListener('mouseup', onUp);
    document.addEventListener('touchend', onUp);

    if (slider) {
        slider.addEventListener('input', function() {
            wheelLightness = parseInt(this.value, 10);
            updateWheelPreview();
        });
    }

    wheelCleanup = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('touchmove', onTouchMove);
        document.removeEventListener('mouseup', onUp);
        document.removeEventListener('touchend', onUp);
        wheelCleanup = null;
    };

    updateWheelPreview();
}

// 颜色池 - 追加颜色值
function appendColorToPool(decimal) {
    const textarea = document.getElementById('text-value');
    const current = textarea.value.trim();
    textarea.value = current ? current + ',' + decimal : String(decimal);
    syncColorPoolDisplay();
}

// 颜色池 - 从色轮添加
function addColorToPool() {
    appendColorToPool(hslToDecimal(wheelHue, 100, wheelLightness));
}

// 颜色池 - 随机添加（crypto 真随机）
function addRandomColorToPool() {
    const arr = new Uint32Array(1);
    crypto.getRandomValues(arr);
    appendColorToPool(arr[0] % 16777216);
}

// 颜色池 - 删除指定颜色
function removeColorFromPool(index) {
    const textarea = document.getElementById('text-value');
    const colors = textarea.value.split(',').map(c => c.trim()).filter(c => c);
    colors.splice(index, 1);
    textarea.value = colors.join(',');
    syncColorPoolDisplay();
}

// 颜色池 - 恢复默认（清空值，后端默认值自动生效）
function resetColorPool() {
    const textarea = document.getElementById('text-value');
    textarea.value = '';
    syncColorPoolDisplay();
}

// 颜色池 - 同步色块展示
function syncColorPoolDisplay() {
    const textarea = document.getElementById('text-value');
    const display = document.getElementById('color-pool-display');
    if (!textarea || !display) return;
    display.innerHTML = renderColorItems(parseColorPool(textarea.value));
}

// 颜色池 - 批量添加弹窗
function showBatchColorDialog() {
    const overlay = document.createElement('div');
    overlay.id = 'batch-color-overlay';
    overlay.className = 'batch-color-overlay';
    overlay.innerHTML = \`
        <div class="batch-color-dialog">
            <div style="font-size: 15px; font-weight: 600; margin-bottom: 12px;">批量添加颜色</div>
            <div class="form-help" style="margin: 0 0 10px 0;">支持十进制（如 16777215）和十六进制（如 #ffffff），逗号分隔</div>
            <textarea id="batch-color-input" class="batch-color-input" placeholder="例如: #ff0000, 65280, #0000ff, 16776960" rows="4"></textarea>
            <div id="batch-color-preview" class="batch-color-preview"></div>
            <div class="batch-color-actions">
                <button type="button" class="btn btn-sm" onclick="closeBatchColorDialog()">取消</button>
                <button type="button" class="btn btn-primary btn-sm" onclick="confirmBatchColor()">确认添加</button>
            </div>
        </div>
    \`;
    document.body.appendChild(overlay);
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) closeBatchColorDialog();
    });
    const input = document.getElementById('batch-color-input');
    if (input) input.addEventListener('input', updateBatchColorPreview);
}

// 颜色池 - 关闭批量弹窗
function closeBatchColorDialog() {
    const overlay = document.getElementById('batch-color-overlay');
    if (overlay) overlay.remove();
}

// 颜色池 - 解析单个颜色值（支持十进制和 #hex）
function parseColorValue(raw) {
    const s = raw.trim();
    if (!s) return NaN;
    if (s.startsWith('#')) {
        const hex = s.slice(1);
        if (/^[0-9a-fA-F]{3}$/.test(hex)) {
            const full = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
            return parseInt(full, 16);
        }
        if (/^[0-9a-fA-F]{6}$/.test(hex)) {
            return parseInt(hex, 16);
        }
        return NaN;
    }
    const n = parseInt(s, 10);
    if (isNaN(n) || n < 0 || n > 16777215) return NaN;
    return n;
}

// 颜色池 - 批量预览
function updateBatchColorPreview() {
    const input = document.getElementById('batch-color-input');
    const preview = document.getElementById('batch-color-preview');
    if (!input || !preview) return;
    const parts = input.value.split(',');
    const html = parts.map(raw => {
        const c = parseColorValue(raw);
        if (isNaN(c)) return '';
        return \`<span class="batch-color-preview-swatch" style="background: #\${c.toString(16).padStart(6, '0')};"></span>\`;
    }).filter(Boolean).join('');
    preview.innerHTML = html || '<span class="color-pool-empty">输入颜色后预览</span>';
}

// 颜色池 - 确认批量添加
function confirmBatchColor() {
    const input = document.getElementById('batch-color-input');
    if (!input) return;
    const parts = input.value.split(',');
    const valid = parts.map(raw => parseColorValue(raw)).filter(c => !isNaN(c));
    if (valid.length === 0) {
        customAlert('未识别到有效颜色值');
        return;
    }
    const textarea = document.getElementById('text-value');
    const current = textarea.value.trim();
    const newVal = valid.map(String).join(',');
    textarea.value = current ? current + ',' + newVal : newVal;
    syncColorPoolDisplay();
    closeBatchColorDialog();
}

// DANMU_OFFSET 快速配置 - 切换规则面板
function toggleOffsetRulePanel() {
    const panel = document.getElementById('offset-rule-panel');
    if (panel) {
        const isHidden = getComputedStyle(panel).display === 'none';
        panel.style.display = isHidden ? 'block' : 'none';
        const btn = document.getElementById('offset-rule-toggle');
        if (btn) btn.innerHTML = isHidden ? uiIcon('chevron-up') + ' 收起' : uiIcon('plus') + ' 添加规则';
    }
}

// DANMU_OFFSET 快速配置 - 切换来源选中状态
function toggleOffsetSource(el) {
    el.classList.toggle('selected');
}

// DANMU_OFFSET 快速配置 - 确认添加规则
function appendOffsetRule() {
    const anime = document.getElementById('offset-anime').value.trim();
    const season = document.getElementById('offset-season').value.trim();
    const episode = document.getElementById('offset-episode').value.trim();
    const seconds = document.getElementById('offset-seconds').value.trim();
    const usePercent = !!document.getElementById('offset-use-percent')?.checked;

    if (!anime) {
        customAlert('请输入剧名');
        return;
    }
    if (!seconds) {
        customAlert('请输入偏移秒数');
        return;
    }
    if (episode && !season) {
        customAlert('指定集时需要同时指定季');
        return;
    }

    let path = anime;
    if (season) {
        path += '/S' + season.padStart(2, '0');
        if (episode) {
            path += '/E' + episode.padStart(2, '0');
        }
    }

    const sourcesEl = document.getElementById('offset-sources');
    if (sourcesEl) {
        const selectedSources = Array.from(sourcesEl.querySelectorAll('.offset-source-tag.selected'))
            .map(el => el.dataset.value);
        if (selectedSources.length > 0) {
            path += '@' + selectedSources.join('&');
        }
    }

    if (usePercent) {
        path += '%';
    }

    const rule = path + ':' + seconds;
    const textarea = document.getElementById('text-value');
    const current = textarea.value.trim();
    textarea.value = current ? current + ',' + rule : rule;

    document.getElementById('offset-anime').value = '';
    document.getElementById('offset-season').value = '';
    document.getElementById('offset-episode').value = '';
    document.getElementById('offset-seconds').value = '';
    const usePercentEl = document.getElementById('offset-use-percent');
    if (usePercentEl) {
        usePercentEl.checked = false;
    }
    if (sourcesEl) {
        sourcesEl.querySelectorAll('.offset-source-tag.selected').forEach(el => {
            el.classList.remove('selected');
        });
    }
    toggleOffsetRulePanel();
}

// CUSTOM_MERGE_RULES 快速配置 - 焦点状态记录
let currentMergeFocus = 'sec';

function setMergeFocus(type) {
    currentMergeFocus = type;
}

// CUSTOM_MERGE_RULES 快速配置 - 快捷追加来源
function appendSourceToMerge(source) {
    const inputId = currentMergeFocus === 'sec' ? 'merge-sec-entity' : 'merge-prim-entity';
    const inputEl = document.getElementById(inputId);
    if (!inputEl) return;

    let val = inputEl.value.trim();
    if (val.includes('@')) {
        val += '&' + source;
    } else {
        val += '@' + source;
    }
    inputEl.value = val;
    inputEl.focus(); // 保持焦点，方便用户连续点击多个来源
}

// CUSTOM_MERGE_RULES 快速配置 - 切换规则面板
function toggleMergeRulePanel() {
    const panel = document.getElementById('merge-rule-panel');
    if (panel) {
        const isHidden = getComputedStyle(panel).display === 'none';
        panel.style.display = isHidden ? 'block' : 'none';
        const btn = document.getElementById('merge-rule-toggle');
        if (btn) btn.innerHTML = isHidden ? uiIcon('chevron-up') + ' 收起' : uiIcon('plus') + ' 添加规则';
    }
}

// CUSTOM_MERGE_RULES 快速配置 - 切换操作符联动
function onMergeActionChange() {
    const action = document.getElementById('merge-action').value;
    const routeRow = document.getElementById('merge-route-row');
    const hint = document.getElementById('merge-action-hint');

    if (action === '×') {
        if (routeRow) routeRow.style.display = 'none';
        if (hint) hint.textContent = '阻断';
    } else {
        if (routeRow) routeRow.style.display = 'flex';
        if (hint) hint.textContent = '合并';
    }
}

// CUSTOM_MERGE_RULES 快速配置 - 确认添加规则
function appendMergeRule() {
    const secEntity = document.getElementById('merge-sec-entity').value.trim();
    const action = document.getElementById('merge-action').value;
    const primEntity = document.getElementById('merge-prim-entity').value.trim();
    const routeRule = document.getElementById('merge-route-rule').value.trim();

    if (!secEntity || !primEntity) {
        customAlert('副源实体和主源实体不能为空');
        return;
    }

    let rule = secEntity + ' ' + action + ' ' + primEntity;
    if (action === '->' && routeRule) {
        rule += ' | ' + routeRule;
    }

    const textarea = document.getElementById('text-value');
    const current = textarea.value.trim();

    if (current && !current.endsWith(';')) {
        textarea.value = current + ';' + rule;
    } else {
        textarea.value = current ? current + rule : rule;
    }

    // 清空表单
    document.getElementById('merge-sec-entity').value = '';
    document.getElementById('merge-prim-entity').value = '';
    document.getElementById('merge-route-rule').value = '';

    toggleMergeRulePanel();
}

// 递增/递减数字输入
function adjustNumber(delta) {
    const display = document.getElementById('num-value');
    const slider = document.getElementById('num-slider');
    let value = parseInt(display.textContent) + delta;

    value = Math.max(parseInt(slider.min), Math.min(parseInt(slider.max), value));

    display.textContent = value;
    slider.value = value;
}

// 更新数字显示
function updateNumberDisplay(value) {
    document.getElementById('num-value').textContent = value;
}

// 选择标签
function selectTag(element) {
    document.querySelectorAll('.tag-option').forEach(el => el.classList.remove('selected'));
    element.classList.add('selected');
}

// 更新标签选项
function updateTagOptions() {
    const input = document.getElementById('select-options');
    const options = input.value.split(',').map(s => s.trim()).filter(s => s);
    const container = document.getElementById('tag-selector');

    container.innerHTML = options.map(opt => \`
        <div class="tag-option" data-value="\${opt}" onclick="selectTag(this)">
            \${opt}
        </div>
    \`).join('');
}

// 统一的状态检查函数
function getSelectedTagElements() {
    const container = document.getElementById('selected-tags');
    if (!container) return [];

    return Array.from(container.children).filter(element =>
        element.classList.contains('selected-tag') && !element.dataset.dragGhost
    );
}

function updateTagStates() {
    // 确保 DOM 元素存在，防止在渲染过程中被调用出错
    // 确保当前编辑配置存在
    if (!editingKeyName) return;

    const currentKey = editingKeyName;
    const isMergeSourcePairs = currentKey === 'MERGE_SOURCE_PAIRS';
    const preventDuplicateSources = currentKey === 'SOURCE_ORDER' || currentKey === 'PLATFORM_ORDER';
    // 1. 获取当前暂存区中的Token (防止同组内重复)
    const stagingTokens = new Set(stagingTags);
    
    // 2. 获取已确认的 Selected Tags (仅在非合并模式下需要检查)
    const selectedTagElements = getSelectedTagElements();
    // PLATFORM_ORDER 的已选项可能是 dandan&animeko，需要将组合拆开后再判断源是否已添加。
    const selectedSourceTokens = new Set(
        selectedTagElements.flatMap(element =>
            String(element.dataset.value || '').split('&').map(value => value.trim()).filter(Boolean)
        )
    );

    // 3. 更新所有可选项的状态
    const availableTags = document.querySelectorAll('.available-tag');
    availableTags.forEach(tag => {
        const value = tag.dataset.value;
        let shouldDisable = false;

        if (isMergeMode) {
            // [合并模式逻辑]
            // 仅禁止同一合并组内重复：已选项需保持可选取，才能把已选源组合成合并组。
            if (stagingTokens.has(value)) {
                shouldDisable = true;
            }
        } else {
            // [普通模式逻辑]
            // 排序配置按组成源判断，其他多选配置保持完整值精准匹配。
            const isAlreadySelected = preventDuplicateSources
                ? selectedSourceTokens.has(value)
                : selectedTagElements.some(el => el.dataset.value === value);
            if (isAlreadySelected) {
                shouldDisable = true;
            }

            // 特殊情况：如果是 MERGE_SOURCE_PAIRS 但没开合并模式，且还没被选，也禁用（强迫用户开开关）
            if (isMergeSourcePairs && !isAlreadySelected) {
                shouldDisable = true;
            }
        }

        if (shouldDisable) {
            tag.classList.add('disabled');
        } else {
            tag.classList.remove('disabled');
        }
    });
}

// 添加已选标签
function addSelectedTag(element) {
    const value = element.dataset.value;

    if (element.classList.contains('disabled')) return;

    if (isMergeMode) {
        if (!stagingTags.includes(value)) {
            stagingTags.push(value);
            renderStagingArea();
            updateTagStates(); // 立即更新状态 (该选项变灰，防止同组重复)
        }
        return;
    }
    
    const container = document.getElementById('selected-tags');

    // 移除empty类
    container.classList.remove('empty');

    // 创建新标签
    const tag = document.createElement('div');
    tag.className = 'selected-tag';
    tag.draggable = true;
    tag.dataset.value = value;
    tag.innerHTML = \`
        <span class="tag-text">\${value}</span>
        <button type="button" class="remove-btn" onclick="removeSelectedTag(this)">×</button>
    \`;

    container.appendChild(tag);
    updateTagStates(); // 立即更新状态
    setupDragAndDrop();
}

// 移除已选标签
function removeSelectedTag(button) {
    const tag = button.parentElement;
    tag.remove();

    const container = document.getElementById('selected-tags');
    if (container.children.length === 0) {
        container.classList.add('empty');
    }

    updateTagStates(); // 移除后立即释放状态
    setupDragAndDrop();
}

// 更新多选选项
function updateMultiOptions() {
    const input = document.getElementById('multi-options');
    const options = input.value.split(',').map(s => s.trim()).filter(s => s);

    const container = document.getElementById('available-tags');
    container.innerHTML = options.map(opt => {
        return \`
            <div class="available-tag"
                 data-value="\${opt}" onclick="addSelectedTag(this)">
                \${opt}
            </div>
        \`;
    }).join('');
    
    updateTagStates(); // 初始化时更新状态
}

// 切换合并模式
function toggleMergeMode() {
    isMergeMode = !isMergeMode;
    const btn = document.getElementById('merge-mode-toggle');
    const stagingArea = document.getElementById('staging-area');

    if (isMergeMode) {
        btn.classList.add('active');
        btn.innerHTML = uiIcon('unlink') + ' 合并模式已开启，点击关闭';
        stagingArea.classList.add('active');
        renderStagingArea();
    } else {
        btn.classList.remove('active');
        btn.innerHTML = uiIcon('link') + ' 点击开启合并模式';
        stagingArea.classList.remove('active');
        stagingTags = [];
    }
    
    // 切换模式时立即刷新所有可选项状态
    updateTagStates();
}

// 渲染暂存区
function renderStagingArea() {
    const container = document.getElementById('staging-area');
    const confirmBtn = container.querySelector('.confirm-merge-btn');
    
    while (container.firstChild && container.firstChild !== confirmBtn) {
        container.removeChild(container.firstChild);
    }

    if (stagingTags.length === 0) {
        const hint = document.createElement('span');
        hint.textContent = '请点击下方选项进行组合...';
        hint.style.color = '#666';
        hint.style.fontSize = '12px';
        container.insertBefore(hint, confirmBtn);
        confirmBtn.disabled = true;
    } else {
        stagingTags.forEach((tag, index) => {
            if (index > 0) {
                const sep = document.createElement('span');
                sep.className = 'staging-separator';
                sep.textContent = '&';
                container.insertBefore(sep, confirmBtn);
            }
            const tagEl = document.createElement('div');
            tagEl.className = 'staging-tag';
            tagEl.draggable = true;
            tagEl.dataset.value = tag;
            tagEl.dataset.index = index;
            tagEl.innerHTML = \`\${tag}<span class="remove-btn" onclick="removeFromStaging(\${index})">×</span>\`;
            container.insertBefore(tagEl, confirmBtn);
        });
        confirmBtn.disabled = false;
        setupStagingDragAndDrop();
    }
}

// 从暂存区移除
function removeFromStaging(index) {
    stagingTags.splice(index, 1);
    renderStagingArea();
    updateTagStates(); // 移除后刷新状态
}

// 确认添加合并组
function confirmMergeGroup() {
    if (stagingTags.length === 0) return;
    const groupValue = stagingTags.join('&');
    const container = document.getElementById('selected-tags');
    container.classList.remove('empty');

    const tag = document.createElement('div');
    tag.className = 'selected-tag';
    tag.draggable = true;
    tag.dataset.value = groupValue;
    tag.innerHTML = \`<span class="tag-text">\${groupValue}</span><button type="button" class="remove-btn" onclick="removeSelectedTag(this)">×</button>\`;
    
    container.appendChild(tag);
    setupDragAndDrop();
    
    stagingTags = []; // 清空暂存区
    renderStagingArea();
    updateTagStates(); // 关键：确认后立即重新计算所有可选项的禁用状态 (重置为可用)
}

// 设置暂存区拖放功能
function setupStagingDragAndDrop() {
    const container = document.getElementById('staging-area');
    const tags = container.querySelectorAll('.staging-tag');
    
    tags.forEach(tag => {
        tag.addEventListener('dragstart', handleStagingDragStart);
        tag.addEventListener('dragend', handleStagingDragEnd);
        tag.addEventListener('dragover', handleStagingDragOver);
        tag.addEventListener('drop', handleStagingDrop);
        tag.addEventListener('dragenter', handleStagingDragEnter);
        tag.addEventListener('dragleave', handleStagingDragLeave);
        
        tag.addEventListener('touchstart', handleStagingTouchStart);
        tag.addEventListener('touchmove', handleStagingTouchMove);
        tag.addEventListener('touchend', handleStagingTouchEnd);
        tag.addEventListener('touchcancel', handleStagingTouchCancel);
    });
}

let stagingDraggedElement = null;

function handleStagingDragStart(e) {
    stagingDraggedElement = this;
    this.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
}

function handleStagingDragEnd(e) {
    this.classList.remove('dragging');
    document.querySelectorAll('.staging-tag').forEach(tag => {
        tag.classList.remove('drag-over');
    });
    stagingDraggedElement = null;
}

function handleStagingDragOver(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }
    e.dataTransfer.dropEffect = 'move';
    return false;
}

function handleStagingDragEnter(e) {
    if (this !== stagingDraggedElement) {
        this.classList.add('drag-over');
    }
}

function handleStagingDragLeave(e) {
    this.classList.remove('drag-over');
}

function handleStagingDrop(e) {
    if (e.stopPropagation) {
        e.stopPropagation();
    }

    if (stagingDraggedElement !== this) {
        const draggedIndex = parseInt(stagingDraggedElement.dataset.index);
        const targetIndex = parseInt(this.dataset.index);
        
        const [movedItem] = stagingTags.splice(draggedIndex, 1);
        stagingTags.splice(targetIndex, 0, movedItem);
        
        renderStagingArea();
    }

    this.classList.remove('drag-over');
    return false;
}

function handleStagingTouchStart(e) {
    if (e.target.classList.contains('remove-btn')) {
        return;
    }
    
    e.preventDefault();
    stagingDraggedElement = this;
    this.classList.add('dragging');
    
    this.style.transform = 'rotate(5deg)';
    this.style.opacity = '0.8';
    this.style.zIndex = '1000';
}

function handleStagingTouchMove(e) {
    if (!stagingDraggedElement) return;
    e.preventDefault();
    
    const touch = e.touches[0];
    const elementRect = stagingDraggedElement.getBoundingClientRect();
    
    if (!document.getElementById('staging-touch-drag-ghost')) {
        const ghostElement = stagingDraggedElement.cloneNode(true);
        ghostElement.id = 'staging-touch-drag-ghost';
        ghostElement.style.position = 'fixed';
        ghostElement.style.left = '0';
        ghostElement.style.top = '0';
        ghostElement.style.pointerEvents = 'none';
        ghostElement.style.zIndex = '9999';
        ghostElement.style.transform = 'translate(' + (touch.clientX - (elementRect.width / 2)) + 'px, ' + (touch.clientY - (elementRect.height / 2)) + 'px) rotate(5deg)';
        ghostElement.style.opacity = '0.8';
        ghostElement.style.boxSizing = 'border-box';
        ghostElement.style.width = elementRect.width + 'px';
        ghostElement.style.height = elementRect.height + 'px';
        document.body.appendChild(ghostElement);
    } else {
        const ghostElement = document.getElementById('staging-touch-drag-ghost');
        ghostElement.style.transform = 'translate(' + (touch.clientX - (elementRect.width / 2)) + 'px, ' + (touch.clientY - (elementRect.height / 2)) + 'px) rotate(5deg)';
    }
    
    const container = document.getElementById('staging-area');
    const tags = Array.from(container.querySelectorAll('.staging-tag')).filter(tag => tag !== stagingDraggedElement);
    let targetElement = null;
    
    for (const tag of tags) {
        const rect = tag.getBoundingClientRect();
        if (touch.clientX >= rect.left && touch.clientX <= rect.right &&
            touch.clientY >= rect.top && touch.clientY <= rect.bottom) {
            targetElement = tag;
            break;
        }
    }
    
    document.querySelectorAll('.staging-tag').forEach(tag => {
        if (tag !== stagingDraggedElement) {
            tag.classList.remove('drag-over');
        }
    });
    
    if (targetElement) {
        targetElement.classList.add('drag-over');
    }
}

function handleStagingTouchEnd(e) {
    if (!stagingDraggedElement) return;
    e.preventDefault();
    
    const ghostElement = document.getElementById('staging-touch-drag-ghost');
    if (ghostElement) {
        document.body.removeChild(ghostElement);
    }
    
    const touch = e.changedTouches[0];
    const targetElement = document.elementFromPoint(touch.clientX, touch.clientY);
    const targetTag = targetElement ? targetElement.closest('.staging-tag') : null;
    
    if (targetTag && targetTag !== stagingDraggedElement) {
        const draggedIndex = parseInt(stagingDraggedElement.dataset.index);
        const targetIndex = parseInt(targetTag.dataset.index);
        
        const [movedItem] = stagingTags.splice(draggedIndex, 1);
        stagingTags.splice(targetIndex, 0, movedItem);
        
        renderStagingArea();
    }
    
    stagingDraggedElement.style.transform = '';
    stagingDraggedElement.style.opacity = '';
    stagingDraggedElement.style.zIndex = '';
    stagingDraggedElement.classList.remove('dragging');
    
    document.querySelectorAll('.staging-tag').forEach(tag => {
        tag.classList.remove('drag-over');
    });
    
    stagingDraggedElement = null;
}

function handleStagingTouchCancel(e) {
    if (e && e.cancelable) e.preventDefault();

    const ghostElement = document.getElementById('staging-touch-drag-ghost');
    if (ghostElement) ghostElement.remove();

    if (stagingDraggedElement) {
        stagingDraggedElement.style.transform = '';
        stagingDraggedElement.style.opacity = '';
        stagingDraggedElement.style.zIndex = '';
        stagingDraggedElement.classList.remove('dragging');
    }

    document.querySelectorAll('#staging-area .staging-tag').forEach(tag => {
        tag.classList.remove('drag-over');
    });
    stagingDraggedElement = null;
}

// 设置拖放功能
let draggedElement = null;
let touchDragging = false;
let touchDragFrame = null;

function setupDragAndDrop() {
    const container = document.getElementById('selected-tags');
    if (!container) return;
    if (container.dataset.dragEventsBound === 'true') return;

    // 使用事件委托，让初始标签和运行时新增标签走同一套拖拽生命周期。
    container.addEventListener('dragstart', handleDelegatedDragStart);
    container.addEventListener('dragend', handleDelegatedDragEnd);
    container.addEventListener('dragover', handleDelegatedDragOver);
    container.addEventListener('drop', handleDelegatedDrop);
    container.addEventListener('dragenter', handleDelegatedDragEnter);
    container.addEventListener('dragleave', handleDelegatedDragLeave);
    container.addEventListener('touchstart', handleDelegatedTouchStart, { passive: false });
    container.dataset.dragEventsBound = 'true';
}

function getEventSelectedTag(e) {
    const container = document.getElementById('selected-tags');
    const tag = e.target && e.target.closest ? e.target.closest('.selected-tag') : null;
    return tag && container && container.contains(tag) && !tag.dataset.dragGhost ? tag : null;
}

function handleDelegatedDragStart(e) {
    const tag = getEventSelectedTag(e);
    if (tag) handleDragStart.call(tag, e);
}

function handleDelegatedDragEnd(e) {
    const tag = getEventSelectedTag(e);
    if (tag) handleDragEnd.call(tag, e);
}

function handleDelegatedDragOver(e) {
    const tag = getEventSelectedTag(e);
    if (tag) {
        handleDragOver.call(tag, e);
    } else {
        handleSelectedTagsContainerDragOver(e);
    }
}

function handleDelegatedDrop(e) {
    const tag = getEventSelectedTag(e);
    if (tag) {
        handleDrop.call(tag, e);
    } else {
        handleSelectedTagsContainerDrop(e);
    }
}

function handleDelegatedDragEnter(e) {
    const tag = getEventSelectedTag(e);
    if (tag) handleDragEnter.call(tag, e);
}

function handleDelegatedDragLeave(e) {
    const tag = getEventSelectedTag(e);
    if (tag) handleDragLeave.call(tag, e);
}

function handleDelegatedTouchStart(e) {
    const tag = getEventSelectedTag(e);
    if (tag) handleTouchStart.call(tag, e);
}

function getSelectedDropTarget(clientX, clientY) {
    const container = document.getElementById('selected-tags');
    if (!container || !draggedElement) return null;

    const pointElement = document.elementFromPoint(clientX, clientY);
    const directTag = pointElement ? pointElement.closest('.selected-tag') : null;
    if (directTag === draggedElement) return null;
    if (directTag && container.contains(directTag) && !directTag.dataset.dragGhost) {
        return { tag: directTag, direct: true };
    }

    const containerRect = container.getBoundingClientRect();
    const insideContainer = clientX >= containerRect.left && clientX <= containerRect.right &&
        clientY >= containerRect.top && clientY <= containerRect.bottom;
    if (!insideContainer) return null;

    const tags = getSelectedTagElements().filter(tag => tag !== draggedElement);
    if (tags.length === 0) return { tag: null, direct: false };

    let closestTag = tags[0];
    let closestDistance = Infinity;
    tags.forEach(tag => {
        const rect = tag.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const distance = Math.pow(clientX - centerX, 2) + Math.pow(clientY - centerY, 2);
        if (distance < closestDistance) {
            closestDistance = distance;
            closestTag = tag;
        }
    });

    return { tag: closestTag, direct: false };
}

function moveSelectedTagToPoint(clientX, clientY) {
    const container = document.getElementById('selected-tags');
    const dropTarget = getSelectedDropTarget(clientX, clientY);
    if (!container || !draggedElement || !dropTarget) return false;

    const targetTag = dropTarget.tag;
    if (!targetTag) {
        container.appendChild(draggedElement);
        return true;
    }

    const allTags = getSelectedTagElements();
    const draggedIndex = allTags.indexOf(draggedElement);
    const targetIndex = allTags.indexOf(targetTag);

    if (dropTarget.direct) {
        container.insertBefore(draggedElement, draggedIndex < targetIndex ? targetTag.nextSibling : targetTag);
        return true;
    }

    const targetRect = targetTag.getBoundingClientRect();
    const onSameRow = clientY >= targetRect.top && clientY <= targetRect.bottom;
    const insertBefore = onSameRow
        ? clientX < targetRect.left + targetRect.width / 2
        : clientY < targetRect.top + targetRect.height / 2;
    container.insertBefore(draggedElement, insertBefore ? targetTag : targetTag.nextSibling);
    return true;
}

function handleSelectedTagsContainerDragOver(e) {
    if (!draggedElement) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
}

function handleSelectedTagsContainerDrop(e) {
    const targetTag = e.target && e.target.closest ? e.target.closest('.selected-tag') : null;
    if (!draggedElement || targetTag) return;
    e.preventDefault();
    e.stopPropagation();
    moveSelectedTagToPoint(e.clientX, e.clientY);
}

function handleDragStart(e) {
    cleanupSelectedTagsTouchDrag();
    draggedElement = this;
    this.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
}

function handleDragEnd(e) {
    this.classList.remove('dragging');
    getSelectedTagElements().forEach(tag => {
        tag.classList.remove('drag-over');
    });
    draggedElement = null;
}

function handleDragOver(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }
    e.dataTransfer.dropEffect = 'move';
    return false;
}

function handleDragEnter(e) {
    if (this !== draggedElement) {
        this.classList.add('drag-over');
    }
}

function handleDragLeave(e) {
    this.classList.remove('drag-over');
}

function handleDrop(e) {
    if (e.stopPropagation) {
        e.stopPropagation();
    }

    if (draggedElement !== this) {
        const container = document.getElementById('selected-tags');
        const allTags = getSelectedTagElements();
        const draggedIndex = allTags.indexOf(draggedElement);
        const targetIndex = allTags.indexOf(this);

        if (draggedIndex < targetIndex) {
            this.parentNode.insertBefore(draggedElement, this.nextSibling);
        } else {
            this.parentNode.insertBefore(draggedElement, this);
        }
    }

    this.classList.remove('drag-over');
    return false;
}

// 触摸拖动事件处理
function handleTouchStart(e) {
    // 检查点击的是否是删除按钮
    if (e.target && e.target.closest && e.target.closest('.remove-btn')) {
        // 如果点击的是删除按钮，则不执行拖动操作
        return;
    }
    
    // 防止默认的触摸行为
    e.preventDefault();
    
    // 模拟拖动开始
    cleanupSelectedTagsTouchDrag();
    draggedElement = this;
    this.classList.add('dragging');
    touchDragging = true;
    
    // 添加拖动样式
    this.style.transform = 'rotate(5deg)';
    this.style.opacity = '0.8';
    this.style.zIndex = '1000';
    
    // 添加触摸移动和结束事件监听器到文档
    document.addEventListener('touchmove', handleTouchMove, { passive: false });
    document.addEventListener('touchend', handleTouchEnd, { passive: false });
    document.addEventListener('touchcancel', handleTouchCancel, { passive: false });
}

function handleTouchMove(e) {
    if (!touchDragging || !draggedElement) return;
    
    // 防止默认的触摸行为
    e.preventDefault();
    
    const touch = e.touches[0];
    if (!touch) return;
    const clientX = touch.clientX;
    const clientY = touch.clientY;

    if (touchDragFrame !== null && window.cancelAnimationFrame) {
        window.cancelAnimationFrame(touchDragFrame);
    }

    const updatePreview = () => {
        touchDragFrame = null;
        if (!touchDragging || !draggedElement) return;

        const elementRect = draggedElement.getBoundingClientRect();
        let ghostElement = document.getElementById('touch-drag-ghost');
        if (!ghostElement) {
            ghostElement = draggedElement.cloneNode(true);
            ghostElement.id = 'touch-drag-ghost';
            ghostElement.dataset.dragGhost = 'true';
            ghostElement.setAttribute('aria-hidden', 'true');
            ghostElement.removeAttribute('draggable');
            ghostElement.style.position = 'fixed';
            ghostElement.style.left = '0';
            ghostElement.style.top = '0';
            ghostElement.style.pointerEvents = 'none';
            ghostElement.style.zIndex = '9999';
            ghostElement.style.opacity = '0.8';
            ghostElement.style.boxSizing = 'border-box';
            ghostElement.style.width = elementRect.width + 'px';
            ghostElement.style.height = elementRect.height + 'px';
            document.body.appendChild(ghostElement);
        }
        ghostElement.style.transform = 'translate(' + (clientX - (elementRect.width / 2)) + 'px, ' + (clientY - (elementRect.height / 2)) + 'px) rotate(5deg)';

        const dropTarget = getSelectedDropTarget(clientX, clientY);
        getSelectedTagElements().forEach(tag => {
            if (tag !== draggedElement) tag.classList.remove('drag-over');
        });
        if (dropTarget && dropTarget.tag) dropTarget.tag.classList.add('drag-over');
    };

    if (window.requestAnimationFrame) {
        touchDragFrame = window.requestAnimationFrame(updatePreview);
    } else {
        updatePreview();
    }
}

function handleTouchEnd(e) {
    if (!touchDragging || !draggedElement) return;
    
    // 防止默认的触摸行为
    e.preventDefault();
    
    const touch = e.changedTouches && e.changedTouches[0];
    if (touch) moveSelectedTagToPoint(touch.clientX, touch.clientY);
    cleanupSelectedTagsTouchDrag();
}

function handleTouchCancel(e) {
    if (e && e.cancelable) e.preventDefault();
    cleanupSelectedTagsTouchDrag();
}

function cleanupSelectedTagsTouchDrag() {
    if (touchDragFrame !== null && window.cancelAnimationFrame) {
        window.cancelAnimationFrame(touchDragFrame);
    }
    touchDragFrame = null;

    const ghostElement = document.getElementById('touch-drag-ghost');
    if (ghostElement) ghostElement.remove();

    if (draggedElement && touchDragging) {
        draggedElement.style.transform = '';
        draggedElement.style.opacity = '';
        draggedElement.style.zIndex = '';
        draggedElement.classList.remove('dragging');
    }
    getSelectedTagElements().forEach(tag => tag.classList.remove('drag-over'));

    touchDragging = false;
    if (draggedElement && !draggedElement.classList.contains('dragging')) draggedElement = null;

    document.removeEventListener('touchmove', handleTouchMove);
    document.removeEventListener('touchend', handleTouchEnd);
    document.removeEventListener('touchcancel', handleTouchCancel);
}

window.addEventListener('blur', cleanupSelectedTagsTouchDrag);

// 显示加载遮罩
function showLoading(text, detail) {
    document.getElementById('loading-text').textContent = text;
    document.getElementById('loading-detail').textContent = detail;
    document.getElementById('loading-overlay').classList.add('active');
    document.getElementById('progress-container').classList.add('active');
    updateProgress(0);
}

// 隐藏加载遮罩
function hideLoading() {
    document.getElementById('loading-overlay').classList.remove('active');
    setTimeout(() => {
        document.getElementById('progress-container').classList.remove('active');
        updateProgress(0);
    }, 300);
}

// 更新加载文本
function updateLoadingText(text, detail) {
    document.getElementById('loading-text').textContent = text;
    document.getElementById('loading-detail').textContent = detail;
}

// 更新进度条
function updateProgress(percent) {
    document.getElementById('progress-bar').style.width = percent + '%';
}

function renderEnvNavigation() {
    const navigation = document.getElementById('env-categories');
    if (!navigation) return;

    navigation.innerHTML = previewCategoryOrder.map(category => {
        const isActive = !envSearchQuery && currentCategory === category;
        return renderCategoryNavButton(category, (envVariables[category] || []).length, isActive, "switchCategory('" + category + "')");
    }).join('');
}

function envItemMatchesSearch(item, category, normalizedQuery) {
    const value = item.value === null || item.value === undefined ? '' : String(item.value);
    const themeLabel = item.key === 'UI_THEME' ? UI_THEMES[value.toLowerCase()] || '' : '';
    return [
        item.key,
        value,
        item.description,
        previewCategoryMeta[category].label,
        themeLabel
    ].join(' ').toLocaleLowerCase().includes(normalizedQuery);
}

function renderEnvItem(item, category, originalIndex) {
    const typeLabel = getEnvTypeLabel(item.type);
    const badgeClass = item.type === 'multi-select' ? 'multi' : '';

    return \`
        <div class="env-item">
            <div class="env-info">
                <strong>\${escapeHtml(item.key)}<span class="value-type-badge \${badgeClass}">\${typeLabel}</span></strong>
                <div class="text-dark-gray">\${escapeHtml(item.value)}</div>
                <div class="text-gray font-size-12 margin-top-3">\${escapeHtml(item.description || '无描述')}</div>
            </div>
            <div class="env-actions">
                <button class="btn btn-primary" onclick="editEnv('\${category}', \${originalIndex}, this)">编辑</button>
                <button class="btn btn-danger" onclick="deleteEnv('\${category}', \${originalIndex}, this)">删除</button>
            </div>
        </div>
    \`;
}

function handleEnvSearch(event) {
    envSearchQuery = event.target.value.trim();
    const clearButton = document.getElementById('env-search-clear');
    if (clearButton) clearButton.hidden = !envSearchQuery;
    renderEnvList();
}

function clearEnvSearch(shouldRender = true) {
    envSearchQuery = '';
    const input = document.getElementById('env-search-input');
    const clearButton = document.getElementById('env-search-clear');
    if (input) input.value = '';
    if (clearButton) clearButton.hidden = true;
    if (shouldRender) {
        renderEnvList();
        if (input) input.focus();
    }
}

// 渲染环境变量列表
function renderEnvList() {
    const list = document.getElementById('env-list');
    const status = document.getElementById('env-search-status');
    const themeSettings = document.getElementById('theme-settings');
    if (!list) return;

    renderEnvNavigation();

    if (!envSearchQuery) {
        const categoryItems = envVariables[currentCategory] || [];
        const items = categoryItems
            .map((item, originalIndex) => ({ item, originalIndex }))
            .filter(({ item }) => item.key !== 'UI_THEME');

        if (themeSettings) themeSettings.hidden = currentCategory !== 'system';
        if (status) status.textContent = previewCategoryMeta[currentCategory].label + ' · ' + categoryItems.length + ' 项';
        list.innerHTML = items.length
            ? items.map(({ item, originalIndex }) => renderEnvItem(item, currentCategory, originalIndex)).join('')
            : '<p class="text-gray padding-20 text-center">暂无配置项</p>';
        return;
    }

    const normalizedQuery = envSearchQuery.toLocaleLowerCase();
    let total = 0;
    let themeMatched = false;
    let html = '';

    previewCategoryOrder.forEach(category => {
        const matches = (envVariables[category] || [])
            .map((item, originalIndex) => ({ item, originalIndex }))
            .filter(({ item }) => envItemMatchesSearch(item, category, normalizedQuery));

        const regularMatches = matches.filter(({ item }) => item.key !== 'UI_THEME');
        themeMatched = themeMatched || matches.some(({ item }) => item.key === 'UI_THEME');
        total += matches.length;

        if (!regularMatches.length) return;
        html += \`
            <section class="preview-group env-search-group">
                <div class="preview-group-heading">
                    \${renderCategoryHeading(category)}
                    <span>\${regularMatches.length} 项</span>
                </div>
                <div>
                    \${regularMatches.map(({ item, originalIndex }) => renderEnvItem(item, category, originalIndex)).join('')}
                </div>
            </section>
        \`;
    });

    if (themeSettings) themeSettings.hidden = !themeMatched;
    if (status) status.textContent = '搜索结果 · ' + total + ' 项';
    list.innerHTML = html || (themeMatched ? '' : '<div class="preview-empty"><strong>未找到匹配配置</strong><span>请尝试其他关键词</span></div>');
}

// 编辑环境变量
function editEnv(category, index, editButton) {
    const item = (envVariables[category] || [])[index];
    if (!item || !editButton) return;
    
    // 设置按钮为加载状态
    const originalText = editButton.innerHTML;
    editButton.innerHTML = '<span class="loading-spinner-small"></span>';
    editButton.disabled = true;
    
    editingKey = index;
    editingCategory = category;
    editingKeyName = item.key;
    editingType = item.type || 'text';

    document.getElementById('modal-title').textContent = '编辑配置项';
    document.getElementById('env-category-display').textContent =
        (previewCategoryMeta[category] && previewCategoryMeta[category].label) || category;
    document.getElementById('env-key-display').textContent = item.key;
    document.getElementById('value-type-display').textContent = getEnvTypeLabel(item.type || 'text');
    document.getElementById('env-description-display').textContent = item.description || '';

    // 渲染对应的值输入控件
    renderValueInput(item);

    document.getElementById('env-modal').classList.add('active');
    lockPageScroll();
    
    // 恢复按钮状态（在实际场景中，这会在编辑完成后发生，比如在保存后或取消后）
    // 为了演示，这里立即恢复按钮状态，实际使用中应该在适当的地方恢复按钮状态
    editButton.innerHTML = originalText;
    editButton.disabled = false;
}

// 删除环境变量
function deleteEnv(category, index, deleteButton) {
    customConfirm('确定要删除这个配置项吗?', '删除确认').then(confirmed => {
        if (confirmed) {
            const item = (envVariables[category] || [])[index];
            if (!item || !deleteButton) return;
            const key = item.key;

            // 设置按钮为加载状态
            const originalText = deleteButton.innerHTML;
            deleteButton.innerHTML = '<span class="loading-spinner-small"></span>';
            deleteButton.disabled = true;

            // 调用API删除环境变量
            fetch(buildApiUrl('/api/env/del'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ key })
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    // 从本地数据中删除
                    envVariables[category].splice(index, 1);
                    renderEnvList();
                    renderPreview();
                    addLog(\`删除配置项: \${key}\`, 'warn');
                } else {
                    addLog(\`删除配置项失败: \${result.message}\`, 'error');
                    addLog(\`❌ 删除配置项失败: \${result.message}\`, 'error');
                }
            })
            .catch(error => {
                addLog(\`删除配置项失败: \${error.message}\`, 'error');
                addLog(\`❌ 删除配置项失败: \${error.message}\`, 'error');
            })
            .finally(() => {
                // 恢复按钮状态
                deleteButton.innerHTML = originalText;
                deleteButton.disabled = false;
            });
        }
    });
}

// 表单提交
document.getElementById('env-form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const category = editingCategory || 'api';
    const key = editingKeyName;
    const description = (document.getElementById('env-description-display').textContent || '').trim();
    const type = editingType;
    const targetCategory = editingCategory || category;
    const existingItem = editingKey !== null && envVariables[targetCategory]
        ? envVariables[targetCategory][editingKey]
        : null;

    // 根据类型获取值
    let value, itemData;

    if (type === 'boolean') {
        value = document.getElementById('bool-value').checked ? 'true' : 'false';
        itemData = { key, value, description, type };
    } else if (type === 'number') {
        value = document.getElementById('num-value').textContent;
        const min = parseInt(document.getElementById('num-slider').min);
        const max = parseInt(document.getElementById('num-slider').max);
        itemData = { key, value, description, type, min, max };
    } else if (type === 'select') {
        const selected = document.querySelector('.tag-option.selected');
        value = selected ? selected.dataset.value : '';
        const options = Array.from(document.querySelectorAll('.tag-option')).map(el => el.dataset.value);
        itemData = { key, value, description, type, options };
    } else if (type === 'multi-select') {
        // 如果开启了合并模式，且暂存区还有内容，自动将其视为确认添加
        if (isMergeMode && stagingTags && stagingTags.length > 0) {
            confirmMergeGroup();
        }

        const selectedTags = [...new Set(
            getSelectedTagElements().map(el => el.dataset.value).filter(Boolean)
        )];
        value = selectedTags.join(',');
        const options = Array.from(document.querySelectorAll('.available-tag')).map(el => el.dataset.value);
        itemData = { key, value, description, type, options };
    } else if (type === 'map') {
        // 获取映射表值
        parseBulkMapItems(true);
        const mapItems = document.querySelectorAll('#map-container .map-item');
        const pairs = [];
        mapItems.forEach(item => {
            const leftInput = item.querySelector('.map-input-left');
            const rightInput = item.querySelector('.map-input-right');
            const leftValue = leftInput.value.trim();
            const rightValue = rightInput.value.trim();
            if (leftValue && rightValue) {
                pairs.push(leftValue + '->' + rightValue);
            }
        });
        value = pairs.join(';');
        itemData = { key, value, description, type };
    } else {
        value = document.getElementById('text-value').value.trim();
        itemData = { key, value, description, type };
    }

    // 调用API更新环境变量 - 先尝试set接口，失败则调用add接口
    try {
        // 首先尝试使用set接口更新
        let response = await fetch(buildApiUrl('/api/env/set'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ key, value })
        });

        let result = await response.json();

        if (!result.success) {
            // 如果set接口失败，尝试使用add接口
            response = await fetch(buildApiUrl('/api/env/add'), {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ key, value })
            });

            result = await response.json();
        }

        if (result.success) {
            // 更新本地数据
            if (!envVariables[category]) {
                envVariables[category] = [];
            }

            if (editingKey !== null) {
                envVariables[targetCategory][editingKey] = {
                    ...(existingItem || {}),
                    ...itemData
                };
                addLog(\`更新配置项: \${key} = \${value}\`, 'success');
            } else {
                envVariables[category].push(itemData);
                addLog(\`添加配置项: \${key} = \${value}\`, 'success');
            }

            if (editingKey === null && category !== currentCategory) {
                currentCategory = category;
                clearEnvSearch(false);
            }

            renderEnvList();
            renderPreview();
            closeModal();
        } else {
            addLog(\`操作失败: \${result.message}\`, 'error');
            addLog(\`❌ 操作失败: \${result.message}\`, 'error');
            customAlert(result.message + '，请检查部署平台相关环境变量配置是否正确');
        }
    } catch (error) {
        addLog(\`更新环境变量失败: \${error.message}\`, 'error');
        addLog(\`❌ 更新环境变量失败: \${error.message}\`, 'error');
        customAlert(error.message + '，请检查部署平台相关环境变量配置是否正确');
    }
});

function parseBulkMapItems(silent = false) {
    const input = document.getElementById('map-bulk-value');
    const container = document.getElementById('map-container');
    if (!input || !container) return false;
    const latest = new Map(); const invalid = [];
    String(input.value || '').split(/[;\\r\\n]+/).forEach((raw, index) => {
        const text = raw.trim(); if (!text) return;
        const pos = text.indexOf('->');
        if (pos < 1 || !text.slice(pos + 2).trim()) { invalid.push(index + 1); return; }
        latest.set(text.slice(0, pos).trim(), text.slice(pos + 2).trim());
    });
    container.querySelectorAll('.map-item').forEach(item => item.remove());
    for (const [left, right] of latest) {
        const row = document.createElement('div'); row.className = 'map-item';
        row.innerHTML = '<input type="text" class="map-input-left"><span class="map-separator">-&gt;</span><input type="text" class="map-input-right"><button type="button" class="btn btn-danger map-remove-btn" onclick="removeMapItem(this)">删除</button>';
        row.querySelector('.map-input-left').value = left;
        row.querySelector('.map-input-right').value = right;
        container.insertBefore(row, container.querySelector('.map-item-template'));
    }
    if (invalid.length && !silent) addLog('Invalid mapping entries ignored: ' + invalid.join(', '), 'warning');
    return invalid.length === 0;
}

// 添加映射项
function addMapItem() {
    const container = document.getElementById('map-container');
    const template = document.querySelector('.map-item-template');
    const newItem = template.cloneNode(true);
    newItem.style.display = 'flex';
    newItem.classList.remove('map-item-template');
    newItem.classList.add('map-item');
    const index = container.querySelectorAll('.map-item').length;
    newItem.setAttribute('data-index', index);
    container.appendChild(newItem);
    newItem.querySelectorAll('.map-input-left, .map-input-right').forEach(input => input.addEventListener('input', syncBulkMapValue));
    syncBulkMapValue();
}

// 删除映射项
function removeMapItem(button) {
    const item = button.closest('.map-item');
    if (item) {
        item.remove();
        syncBulkMapValue();
    }
}

function syncBulkMapValue() {
    const input = document.getElementById('map-bulk-value');
    if (!input) return;
    input.value = Array.from(document.querySelectorAll('#map-container .map-item')).map(item => {
        const l = item.querySelector('.map-input-left')?.value.trim();
        const r = item.querySelector('.map-input-right')?.value.trim();
        return l && r ? l + '->' + r : '';
    }).filter(Boolean).join(';');
}

function bindMapInputSync() {
    document.querySelectorAll('#map-container .map-input-left, #map-container .map-input-right').forEach(input => {
        input.addEventListener('input', syncBulkMapValue);
    });
}
/* ========================================
   Bilibili Cookie 扫码登录功能
   ======================================== */
let biliQRCheckInterval = null;
let biliBiliQRKey = null;

async function startBilibiliQRLogin() {
    // 创建扫码登录模态框
    if (!document.getElementById('bili-qr-modal')) {
        const modalHTML = \`
            <div class="modal" id="bili-qr-modal">
                <div class="modal-content" style="max-width: 400px;">
                    <div class="modal-header">
                        <h3 class="ui-icon-label">\${uiIcon('qr-code')} 扫码登录 Bilibili</h3>
                        <button class="close-btn" onclick="closeBiliQRModal()">×</button>
                    </div>
                    <div class="modal-body" style="text-align: center;">
                        <div id="bili-qr-container">
                            <div class="loading-spinner" id="bili-qr-loading"></div>
                            <p id="bili-qr-status">正在生成二维码...</p>
                            <div id="bili-qr-code" style="display: none;"></div>
                        </div>
                    </div>
                </div>
            </div>
        \`;
        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }
    
    const modal = document.getElementById('bili-qr-modal');
    const qrCode = document.getElementById('bili-qr-code');
    const qrLoading = document.getElementById('bili-qr-loading');
    const qrStatus = document.getElementById('bili-qr-status');
    
    modal.classList.add('active');
    qrCode.style.display = 'none';
    qrCode.innerHTML = '';
    qrLoading.style.display = 'block';
    qrStatus.textContent = '正在生成二维码...';
    
    if (biliQRCheckInterval) {
        clearInterval(biliQRCheckInterval);
    }
    
    try {
        const response = await fetch(buildApiUrl('/api/cookie/qr/generate', true), {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.success && result.data) {
            biliBiliQRKey = result.data.qrcode_key;
            const qrUrl = result.data.url;
            
            qrCode.innerHTML = '<img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + encodeURIComponent(qrUrl) + '" alt="二维码">';
            qrCode.style.display = 'block';
            qrLoading.style.display = 'none';
            qrStatus.textContent = '请使用 Bilibili APP 扫描';
            
            startBiliQRCheck();
        } else {
            throw new Error(result.message || '生成二维码失败');
        }
    } catch (error) {
        qrLoading.style.display = 'none';
        uiSetStatus(qrStatus, 'x-circle', error.message);
    }
}

function startBiliQRCheck() {
    if (!biliBiliQRKey) return;
    
    const qrStatus = document.getElementById('bili-qr-status');
    
    biliQRCheckInterval = setInterval(async () => {
        try {
            const response = await fetch(buildApiUrl('/api/cookie/qr/check', true), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ qrcode_key: biliBiliQRKey })
            });
            
            const result = await response.json();
            
            if (result.success && result.data) {
                const code = result.data.code;
                
                switch (code) {
                    case 86101:
                        uiSetStatus(qrStatus, 'clock', '等待扫码...');
                        break;
                    case 86090:
                        uiSetStatus(qrStatus, 'qr-code', '已扫码，请确认');
                        break;
                    case 86038:
                        uiSetStatus(qrStatus, 'x-circle', '二维码已过期');
                        clearInterval(biliQRCheckInterval);
                        break;
                    case 0:
                        uiSetStatus(qrStatus, 'check-circle', '登录成功！');
                        clearInterval(biliQRCheckInterval);
                        
                        if (result.data.cookie) {
                            fillBilibiliCookie(result.data.cookie);
                        }
                        
                        setTimeout(() => {
                            closeBiliQRModal();
                        }, 1000);
                        break;
                }
            }
        } catch (error) {
            console.error('检查扫码状态失败:', error);
        }
    }, 2000);
}

function fillBilibiliCookie(cookie) {
    const textInput = document.getElementById('text-value');
    if (textInput) {
        textInput.value = cookie;
        textInput.dispatchEvent(new Event('input', { bubbles: true }));
        
        textInput.style.borderColor = 'var(--success-color, #28a745)';
        setTimeout(() => {
            textInput.style.borderColor = '';
            // 填入后触发检测一次（会提示用户保存）
            autoCheckBilibiliCookieStatus();
        }, 2000);
    }
}

function closeBiliQRModal() {
    const modal = document.getElementById('bili-qr-modal');
    if (modal) {
        modal.classList.remove('active');
    }
    
    if (biliQRCheckInterval) {
        clearInterval(biliQRCheckInterval);
    }
}

async function autoCheckBilibiliCookieStatus() {
    const textInput = document.getElementById('text-value');
    const statusEl = document.getElementById('bili-cookie-status');
    
    if (!textInput || !statusEl) return;
    
    const cookie = textInput.value.trim();
    
    // 如果输入框为空,提示未配置
    if (!cookie) {
        statusEl.innerHTML = \`<span class="bili-status-icon">\${uiIcon('alert-triangle')}</span><span class="bili-status-text">未配置</span>\`;
        return;
    }
    
    statusEl.innerHTML = \`<span class="bili-status-icon">\${uiIcon('search')}</span><span class="bili-status-text">检测中...</span>\`;

    // 脱敏后的 *...* 无法直接校验，后端会自动改为校验“已保存”的 Cookie
    const isMasked = /^[*]+$/.test(cookie);
    const payload = isMasked ? {} : { cookie };

    try {
        const response = await fetch(buildApiUrl('/api/cookie/verify', true), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const result = await response.json();

        if (result && result.success && result.data) {
            if (result.data.isValid) {
                const uname = result.data.uname || '已登录';
                const expiresAt = result.data.expiresAt;
                const now = Math.floor(Date.now() / 1000);

                let leftText = '';
                if (typeof expiresAt === 'number' && expiresAt > now) {
                    const daysLeft = Math.ceil((expiresAt - now) / (24 * 60 * 60));
                    leftText = \` (剩余 \${daysLeft} 天)\`;
                }

                // 用户手动输入/扫码填入的 Cookie → 提示保存
                if (!isMasked) {
                    statusEl.innerHTML = \`<span class="bili-status-icon">\${uiIcon('check-circle')}</span><span class="bili-status-text">\${uname}\${leftText} · 请点击保存按钮（Vercel等平台需重新部署后生效）</span>\`;
                } else {
                    // 脱敏显示时只展示当前已保存 Cookie 的状态
                    statusEl.innerHTML = \`<span class="bili-status-icon">\${uiIcon('check-circle')}</span><span class="bili-status-text">\${uname}\${leftText}</span>\`;
                }
            } else {
                const err = result.data.error || 'Cookie无效或已失效';
                statusEl.innerHTML = \`<span class="bili-status-icon">\${uiIcon('x-circle')}</span><span class="bili-status-text">\${err}，请重新扫码登录并保存</span>\`;
            }
        } else {
            statusEl.innerHTML = \`<span class="bili-status-icon">\${uiIcon('alert-triangle')}</span><span class="bili-status-text">检测失败</span>\`;
        }
    } catch (error) {
        statusEl.innerHTML = \`<span class="bili-status-icon">\${uiIcon('alert-triangle')}</span><span class="bili-status-text">检测失败</span>\`;
    }
}
// 显示 Bilibili Cookie 保存提示
function showBilibiliCookieSaveHint(text) {
    const statusEl = document.getElementById('bili-cookie-status');
    if (!statusEl) return;

    const msg = text || '请点击保存按钮,Vercel等平台需重新部署后生效';
    statusEl.innerHTML = \`<span class="bili-status-icon">\${uiIcon('save')}</span><span class="bili-status-text">\${msg}</span>\`;
}

/* ========================================
   AI API Key 连通性测试功能
   ======================================== */
async function verifyAiConnection() {
    const statusEl = document.getElementById('ai-apikey-status');
    const btn = document.getElementById('ai-verify-btn');
    const textInput = document.getElementById('text-value');
    
    if (!statusEl || !textInput) return;
    
    const apiKey = textInput.value.trim();
    
    // 如果输入框为空，提示未配置
    if (!apiKey) {
        statusEl.innerHTML = \`<span class="ai-status-icon">\${uiIcon('alert-triangle')}</span><span class="ai-status-text">请先输入 API Key</span>\`;
        return;
    }
    
    // 设置按钮为加载状态
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="loading-spinner-small"></span>';
    btn.disabled = true;
    
    statusEl.innerHTML = \`<span class="ai-status-icon">\${uiIcon('search')}</span><span class="ai-status-text">正在测试连通性...</span>\`;
    
    // 检查是否为脱敏后的 *...* 
    const isMasked = /^[*]+$/.test(apiKey);
    
    try {
        const response = await fetch(buildApiUrl('/api/ai/verify', true), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(isMasked ? {} : { 'aiApiKey': apiKey })
        });
        
        const result = await response.json();
        
        if (result.ok) {
            statusEl.innerHTML = \`<span class="ai-status-icon">\${uiIcon('check-circle')}</span><span class="ai-status-text">\${result.message || 'AI 服务连通性测试成功'}</span>\`;
            statusEl.style.color = 'var(--success-color, #28a745)';
        } else {
            statusEl.innerHTML = \`<span class="ai-status-icon">\${uiIcon('x-circle')}</span><span class="ai-status-text">\${result.message || '连通性测试失败'}</span>\`;
            statusEl.style.color = 'var(--danger-color, #dc3545)';
        }
    } catch (error) {
        statusEl.innerHTML = \`<span class="ai-status-icon">\${uiIcon('alert-triangle')}</span><span class="ai-status-text">测试请求失败: \${error.message}</span>\`;
        statusEl.style.color = 'var(--warning-color, #ffc107)';
    } finally {
        // 恢复按钮状态
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

/* ========================================
   最近数据与animes缓存面板功能
   ======================================== */

// 统一切换卡片内的折叠区域
function toggleCardSection(btnEl, targetSelector, openText, closeText) {
    if (!btnEl) return;
    const card = btnEl.closest('.anime-cache-card');
    if (!card) return;
    const container = card.querySelector(targetSelector);
    if (!container) return;

    const isHidden = window.getComputedStyle(container).display === 'none';
    btnEl.querySelector('.cache-badge-label').textContent = isHidden ? closeText : openText;

    if (isHidden) {
        container.style.display = 'flex';
        btnEl.classList.add('active');
    } else {
        container.style.display = 'none';
        btnEl.classList.remove('active');
    }
}

// 切换子节点内的映射详情
function toggleMapping(btnEl) {
    if (!btnEl) return;
    const parentItem = btnEl.closest('.anime-cache-child-item');
    if (!parentItem) return;
    const container = parentItem.querySelector('.child-mapping-container');
    if (!container) return;

    const isHidden = window.getComputedStyle(container).display === 'none';
    if (isHidden) {
        container.style.display = 'flex';
        btnEl.innerHTML = '<span class="ui-icon-label">' + uiIcon('list') + ' 收起映射详情</span>';
        btnEl.classList.add('active');
    } else {
        container.style.display = 'none';
        btnEl.innerHTML = '<span class="ui-icon-label">' + uiIcon('list') + ' 展开映射详情</span>';
        btnEl.classList.remove('active');
    }
}

// 最近数据分页状态
const RECENT_DATA_PAGE_SIZE = 5;
let recentAnimeCacheData = []; // 最近数据完整缓存
let recentAnimeDisplayedCount = 0; // 最近数据已显示条数

// 查看最近数据按钮：各配置页共用；className 用于与同行操作按钮保持同一尺寸
function renderRecentDataButton(className = 'btn btn-primary btn-sm') {
    return \`<button type="button" class="\${className}" onclick="fetchAndShowRecentData()">\${uiIcon('bar-chart')} 查看最近数据</button>\`;
}

// 查看最近数据折叠面板：hint 传入时作为面板内的提示文案
function renderRecentDataPanel(hint) {
    return \`
        <div id="recent-data-panel" class="recent-data-panel">
            \${hint ? \`<div class="form-help" style="margin: 0 0 8px 0;">\${hint}</div>\` : ''}
            <div id="recent-data-list"></div>
        </div>
    \`;
}

// 快捷数据面板业务逻辑
async function fetchAndShowRecentData() {
    const panel = document.getElementById('recent-data-panel');
    const listContainer = document.getElementById('recent-data-list');

    if (!panel || !listContainer) return;

    if (window.getComputedStyle(panel).display !== 'none') {
        panel.style.display = 'none';
        return;
    }

    panel.style.display = 'block';
    listContainer.innerHTML = '<span class="loading-spinner-small"></span> 数据加载中...';

    try {
        const response = await fetch(buildApiUrl('/api/cache/animes', true));
        const result = await response.json();

        if (result.success && result.data && result.data.length > 0) {
            recentAnimeCacheData = result.data;
            recentAnimeDisplayedCount = 0;
            renderAnimeCachePanel(result.data, listContainer);
        } else {
            listContainer.innerHTML = '<div class="text-gray font-size-12" style="padding: 10px 0;">缓存中暂无番剧数据，请先通过客户端请求弹幕接口以生成缓存。</div>';
        }
    } catch (error) {
        listContainer.innerHTML = \`<div class="text-red font-size-12">请求失败: \${error.message}</div>\`;
    }
}

// 渲染animes缓存面板 (含集数解析与映射详情)
function renderAnimeCachePanel(data, listContainer) {
    if (!listContainer || !editingKeyName) return;

    const currentKey = editingKeyName;

    // 内部辅助函数：生成操作按钮
    const generateButtons = (title, source) => {
        const safeTitle = escapeHtml(title);
        const safeSource = escapeHtml(source);
        if (currentKey === 'CUSTOM_MERGE_RULES') {
            return \`
                <div style="display:flex;flex-direction:column;gap:4px;">
                    <button type="button" class="btn btn-sm btn-xs" data-fill-action="merge-sec" data-fill-title="\${safeTitle}" data-fill-source="\${safeSource}">设为副</button>
                    <button type="button" class="btn btn-sm btn-primary btn-xs" data-fill-action="merge-prim" data-fill-title="\${safeTitle}" data-fill-source="\${safeSource}">设为主</button>
                </div>
            \`;
        } else if (currentKey === 'DANMU_OFFSET') {
            return \`
                <button type="button" class="btn btn-sm btn-primary btn-xs" data-fill-action="offset" data-fill-title="\${safeTitle}" data-fill-source="\${safeSource}">填入</button>
            \`;
        }
        return '';
    };

    // 内部辅助函数：清洗标题
    const cleanTitleStr = (rawTitle) => rawTitle.replace(/\\s*from\\s+.*$/i, '').trim();

    const nextCount = Math.min(recentAnimeDisplayedCount + RECENT_DATA_PAGE_SIZE, data.length);
    const newItems = data.slice(recentAnimeDisplayedCount, nextCount);

    let html = recentAnimeDisplayedCount === 0 ? '<div class="anime-cache-list">' : '';

    newItems.forEach(item => {
        const cleanTitle = cleanTitleStr(item.animeTitle);
        const coverHtml = item.imageUrl ? \`<img class="anime-cache-cover" src="\${escapeHtml(item.imageUrl)}" alt="" referrerpolicy="no-referrer" loading="lazy">\` : '<div class="anime-cache-cover"></div>';

        // 1. 构建合并子源模块
        let childrenHtml = '';
        let childrenCount = 0;
        if (item.mergedChildren && item.mergedChildren.length > 0) {
            childrenCount = item.mergedChildren.length;
            const childItems = item.mergedChildren.map(child => {
                const childCleanTitle = cleanTitleStr(child.animeTitle);

                const childCoverHtml = child.imageUrl ? \`<img class="anime-cache-child-cover" src="\${escapeHtml(child.imageUrl)}" alt="" referrerpolicy="no-referrer" loading="lazy">\` : '<div class="anime-cache-child-cover"></div>';

                // 解析映射数据并按匹配状态排序
                let mappingHtml = '';
                if (item.links && item.links.length > 0) {
                    const parsedRows = [];

                    item.links.forEach((link, idx) => {
                        const urlStr = String(link.url || '');
                        const hasMainMatch = urlStr.includes(item.source + ':') || !urlStr.includes(':');
                        const hasChildMatch = urlStr.includes(child.source + ':');

                        if (!hasMainMatch && !hasChildMatch) return;

                        let mainSide = '(主源越界)';
                        if (hasMainMatch) {
                            const cleanMainEpTitle = escapeHtml((link.title || '未知剧集').replace(/^【.*?】\\s*/, ''));
                            mainSide = \`【\${escapeHtml(item.source)}】\${cleanMainEpTitle}\`;
                        }

                        let childSide = '(副源缺失)';
                        let childNum = NaN;

                        if (hasChildMatch) {
                            const regex = new RegExp(child.source + ':([^$]+)');
                            const match = urlStr.match(regex);
                            let childTitleStr = '(源ID未知)';

                            if (match) {
                                const childId = match[1];
                                childTitleStr = \`(源ID: \${childId})\`;

                                if (child.links && child.links.length > 0) {
                                    const childLink = child.links.find(l => String(l.url) === String(childId));
                                    if (childLink && childLink.title) {
                                        childTitleStr = childLink.title.replace(/^【.*?】\\s*/, '');
                                    }
                                }
                            } else {
                                childTitleStr = (link.title || '').replace(/^【.*?】\\s*/, '');
                            }
                            childSide = \`【\${escapeHtml(child.source)}】\${escapeHtml(childTitleStr)}\`;
                            
                            const numMatch = childTitleStr.match(/\\d+/);
                            if (numMatch) {
                                childNum = parseInt(numMatch[0], 10);
                            }
                        }

                        let rowHtml = '';
                        if (hasMainMatch && hasChildMatch) {
                            rowHtml = \`<div class="mapping-row"><span class="mapping-status success ui-icon-label">\${uiIcon('check')} 匹配</span> <span class="mapping-text">\${mainSide} ↔ \${childSide}</span></div>\`;
                        } else {
                            rowHtml = \`<div class="mapping-row"><span class="mapping-status warning ui-icon-label">\${uiIcon('x')} 落单</span> <span class="mapping-text">\${mainSide} ↔ \${childSide}</span></div>\`;
                        }

                        parsedRows.push({
                            originalIndex: idx,
                            hasChildMatch: hasChildMatch,
                            childNum: childNum,
                            html: rowHtml
                        });
                    });

                    const matchedRows = parsedRows.filter(r => r.hasChildMatch).sort((a, b) => {
                        if (!isNaN(a.childNum) && !isNaN(b.childNum)) {
                            return a.childNum - b.childNum;
                        }
                        return a.originalIndex - b.originalIndex;
                    });

                    const lonelyRows = parsedRows.filter(r => !r.hasChildMatch).sort((a, b) => a.originalIndex - b.originalIndex);

                    const finalRows = [...matchedRows, ...lonelyRows];
                    const mappingRowsHtml = finalRows.map(r => r.html).join('');

                    if (mappingRowsHtml) {
                        mappingHtml = \`
                            <div class="child-mapping-toggle" onclick="toggleMapping(this)"><span class="ui-icon-label">\${uiIcon('list')} 展开映射详情</span></div>
                            <div class="child-mapping-container">
                                \${mappingRowsHtml}
                            </div>
                        \`;
                    }
                }

                return \`
                    <div class="anime-cache-child-item">
                        <div class="anime-cache-child-main">
                            \${childCoverHtml}
                            <div class="anime-cache-child-info">
                                <div class="anime-cache-child-title" title="\${escapeHtml(child.animeTitle)}">\${escapeHtml(childCleanTitle)}</div>
                                <div class="anime-cache-meta">[\${escapeHtml(child.source)}] (\${child.episodes}集)</div>
                            </div>
                            <div class="anime-cache-child-actions">
                                \${generateButtons(childCleanTitle, child.source)}
                            </div>
                        </div>
                        \${mappingHtml}
                    </div>
                \`;
            }).join('');

            childrenHtml = \`
                <div class="merged-children-container">
                    \${childItems}
                </div>
            \`;
        }

        // 2. 构建剧集参考列表模块
        let episodesHtml = '';
        let episodesCount = 0;
        if (item.links && item.links.length > 0) {
            episodesCount = item.links.length;
            const epItems = item.links.map(link => {
                const safeTitle = link.title ? escapeHtml(link.title) : '未知剧集';
                return \`
                    <div class="anime-cache-child-item" style="padding: 6px;">
                        <div class="anime-cache-child-main">
                            <div class="anime-cache-child-info">
                                <div class="anime-cache-child-title" title="\${safeTitle}">\${safeTitle}</div>
                            </div>
                        </div>
                    </div>
                \`;
            }).join('');

            episodesHtml = \`
                <div class="episodes-list-container">
                    \${epItems}
                </div>
            \`;
        }

        // 3. 构建卡片底部专属切换栏 (Tab Bar)
        let footerHtml = '';
        if (childrenCount > 0 || episodesCount > 0) {
            let badges = '';
            if (episodesCount > 0) {
                badges += \`<div class="cache-badge badge-episodes" onclick="toggleCardSection(this, '.episodes-list-container', '\${episodesCount} 个剧集', '收起剧集')">\${uiIcon('film')}<span class="cache-badge-label">\${episodesCount} 个剧集</span></div>\`;
            }
            if (childrenCount > 0) {
                badges += \`<div class="cache-badge badge-sources" onclick="toggleCardSection(this, '.merged-children-container', '\${childrenCount} 个被合并源', '收起被合并源')">\${uiIcon('link')}<span class="cache-badge-label">\${childrenCount} 个被合并源</span></div>\`;
            }
            footerHtml = \`<div class="anime-cache-footer">\${badges}</div>\`;
        }

        // 4. 组装完整卡片
        html += \`
            <div class="anime-cache-card">
                <div class="anime-cache-card-body">
                    \${coverHtml}
                    <div class="anime-cache-info">
                        <div class="anime-cache-title" title="\${escapeHtml(item.animeTitle)}">\${escapeHtml(cleanTitle)}</div>
                        <div class="anime-cache-meta">[\${escapeHtml(item.source)}] (\${item.episodes}集)</div>
                    </div>
                    <div class="anime-cache-actions">
                        \${generateButtons(cleanTitle, item.source)}
                    </div>
                </div>
                \${footerHtml}
                \${childrenHtml}
                \${episodesHtml}
            </div>
        \`;
    });

    if (recentAnimeDisplayedCount === 0) {
        html += '</div>';
        listContainer.innerHTML = html;
    } else {
        const listEl = listContainer.querySelector('.anime-cache-list');
        if (listEl) listEl.insertAdjacentHTML('beforeend', html);
    }

    recentAnimeDisplayedCount = nextCount;
    updateRecentDataLoadMore(listContainer, data.length, nextCount);
}

// 更新最近数据加载更多按钮
function updateRecentDataLoadMore(listContainer, total, displayed) {
    let loadMoreBtn = listContainer.querySelector('.recent-data-load-more');
    if (displayed < total) {
        if (!loadMoreBtn) {
            loadMoreBtn = document.createElement('button');
            loadMoreBtn.type = 'button';
            loadMoreBtn.className = 'btn btn-primary btn-sm recent-data-load-more';
            loadMoreBtn.onclick = loadMoreRecentData;
            listContainer.appendChild(loadMoreBtn);
        }
        loadMoreBtn.textContent = '加载更多 (' + displayed + '/' + total + ')';
    } else if (loadMoreBtn) {
        loadMoreBtn.remove();
    }
}

// 加载更多最近数据
function loadMoreRecentData() {
    const listContainer = document.getElementById('recent-data-list');
    if (!listContainer) return;
    renderAnimeCachePanel(recentAnimeCacheData, listContainer);
}

/* ========================================
   表单填充快捷操作功能
   ======================================== */

// 内部辅助函数：输入框视觉反馈统一处理
function applyInputFeedback(inputEl) {
    if (!inputEl) return;
    const oldBorder = inputEl.style.borderColor;
    inputEl.style.borderColor = '#28a745';
    setTimeout(() => inputEl.style.borderColor = oldBorder, 800);
}

// 表单填充逻辑：合并映射表
function fillMergeEntity(type, title, source) {
    const panel = document.getElementById('merge-rule-panel');
    if (panel && window.getComputedStyle(panel).display === 'none') {
        toggleMergeRulePanel();
    }

    const inputId = type === 'sec' ? 'merge-sec-entity' : 'merge-prim-entity';
    const inputEl = document.getElementById(inputId);

    if (inputEl) {
        inputEl.value = \`\${title}@\${source}\`;
        applyInputFeedback(inputEl);
        setMergeFocus(type);
    }
}

// 表单填充逻辑：弹幕偏移
function fillOffsetEntity(title, source) {
    const panel = document.getElementById('offset-rule-panel');
    if (panel && window.getComputedStyle(panel).display === 'none') {
        toggleOffsetRulePanel();
    }

    // 视图层数据清洗：去除年份和类型后缀
    const cleanTitle = title
        .replace(/[\\u200B-\\u200F\\uFEFF]/g, '')
        .replace(/\\s*[（(〔\\[]\\s*[0-9０-９]{4}\\s*年?\\s*[）)〕\\]]/g, '') 
        .replace(/(.+?)\\s*【[^】]+】$/, '$1')
        .trim();

    const inputEl = document.getElementById('offset-anime');

    if (inputEl) {
        inputEl.value = cleanTitle;

        // 基于 data-value 属性匹配并选中对应来源标签
        const sourceTags = document.querySelectorAll('#offset-sources .offset-source-tag');
        if (sourceTags.length > 0) {
            sourceTags.forEach(el => el.classList.remove('selected'));
            const targetTag = Array.from(sourceTags).find(el => el.dataset.value === source);
            if (targetTag) targetTag.classList.add('selected');
        }

        applyInputFeedback(inputEl);
    }
}

// 处理最近数据面板快捷填入按钮的点击
document.addEventListener('click', function(e) {
    const btn = e.target.closest('[data-fill-action]');
    if (!btn) return;
    const action = btn.dataset.fillAction;
    const title = btn.dataset.fillTitle;
    const source = btn.dataset.fillSource;
    if (action === 'offset') {
        fillOffsetEntity(title, source);
    } else if (action === 'merge-sec') {
        fillMergeEntity('sec', title, source);
    } else if (action === 'merge-prim') {
        fillMergeEntity('prim', title, source);
    }
});
`;
